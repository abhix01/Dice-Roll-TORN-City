import { Router, type IRouter } from "express";
import { db, playersTable, rollsTable, jackpotPoolTable } from "@workspace/db";
import { eq, desc, ne, sql } from "drizzle-orm";
import {
  RollDiceBody,
  RollDiceResponse,
  GetMyHistoryResponse,
  GetRecentWinnersResponse,
  GetMyHistoryQueryParams,
  GetJackpotResponse,
  GetDailyBonusResponse,
  ClaimDailyBonusResponse,
  GetAchievementsResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";
import { generateRollNumber, calculateResult, JACKPOT_MIN_BET } from "../lib/game";
import { checkAndAwardAchievements, getPlayerAchievements } from "../lib/achievements";

const router: IRouter = Router();

const JACKPOT_SEED = 10_000_000;
const JACKPOT_CONTRIBUTION_RATE = 0.05; // 5% of every losing bet feeds the pool

async function getOrCreatePool() {
  const rows = await db.select().from(jackpotPoolTable).limit(1);
  if (rows.length > 0) return rows[0];
  const [created] = await db.insert(jackpotPoolTable).values({ pool: JACKPOT_SEED }).returning();
  return created;
}

router.get("/game/jackpot", async (_req, res): Promise<void> => {
  const row = await getOrCreatePool();
  res.json(GetJackpotResponse.parse({ pool: row.pool }));
});

router.post("/game/roll", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const player = req.player!;

  const parsed = RollDiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { betAmount } = parsed.data;

  if (betAmount > player.balance) {
    res.status(400).json({ error: "Insufficient balance" });
    return;
  }

  const jackpotRow = await getOrCreatePool();
  const rollNumber = generateRollNumber();

  // Only bets strictly above JACKPOT_MIN_BET are eligible for the jackpot.
  // Small bets (10K / 50K / 100K) hitting 99–100 resolve as big_win instead.
  const jackpotEligible = betAmount > JACKPOT_MIN_BET;
  const isJackpot = rollNumber >= 99 && jackpotEligible;

  let payout: number;
  let resultType: string;
  let newPool: number;

  if (isJackpot) {
    // Guarantee the jackpot always pays at least 2× the bet so it's always a net win
    payout = Math.max(jackpotRow.pool, betAmount * 2);
    resultType = "jackpot";
    newPool = JACKPOT_SEED;
  } else {
    // calculateResult handles 1-60 lose, 61-90 small_win, 91-100 big_win
    // (jackpot-territory rolls on ineligible bets become big_win automatically)
    const result = calculateResult(rollNumber, betAmount);
    payout = result.payout;
    resultType = result.resultType;
    // Losing rolls feed the jackpot pool
    if (resultType === "lose") {
      newPool = jackpotRow.pool + Math.floor(betAmount * JACKPOT_CONTRIBUTION_RATE);
    } else {
      newPool = jackpotRow.pool;
    }
  }

  const isWin = resultType !== "lose";
  const netChange = payout - betAmount;

  const [roll] = await db
    .insert(rollsTable)
    .values({ playerId: player.id, rollNumber, resultType, betAmount, payout })
    .returning();

  const [updatedPlayer] = await db
    .update(playersTable)
    .set({
      balance: sql`${playersTable.balance} + ${netChange}`,
      totalRolls: sql`${playersTable.totalRolls} + 1`,
      totalWon: isWin ? sql`${playersTable.totalWon} + ${payout}` : playersTable.totalWon,
      totalLost: !isWin ? sql`${playersTable.totalLost} + 1` : playersTable.totalLost,
    })
    .where(eq(playersTable.id, player.id))
    .returning();

  // Update jackpot pool
  await db
    .update(jackpotPoolTable)
    .set({ pool: newPool, updatedAt: new Date() })
    .where(eq(jackpotPoolTable.id, jackpotRow.id));

  // Check and award any achievements earned by this roll
  const newAchievements = await checkAndAwardAchievements(player.id, {
    resultType,
    betAmount,
    totalRolls: updatedPlayer.totalRolls,
  });

  res.json(
    RollDiceResponse.parse({
      id: roll.id,
      rollNumber: roll.rollNumber,
      resultType: roll.resultType,
      betAmount: roll.betAmount,
      payout: roll.payout,
      jackpotPool: newPool,
      newAchievements: newAchievements.map((a) => ({
        id: a.id,
        name: a.name,
        description: a.description,
        emoji: a.emoji,
        earnedAt: new Date().toISOString(),
      })),
      player: {
        id: updatedPlayer.id,
        tornId: updatedPlayer.tornId,
        name: updatedPlayer.name,
        level: updatedPlayer.level,
        faction: updatedPlayer.faction,
        balance: updatedPlayer.balance,
        totalRolls: updatedPlayer.totalRolls,
        totalWon: updatedPlayer.totalWon,
        totalLost: updatedPlayer.totalLost,
        createdAt: updatedPlayer.createdAt.toISOString(),
      },
    })
  );
});

router.get("/game/history", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const player = req.player!;
  const queryParsed = GetMyHistoryQueryParams.safeParse(req.query);
  const limit = queryParsed.success ? (queryParsed.data.limit ?? 20) : 20;

  const rolls = await db
    .select()
    .from(rollsTable)
    .where(eq(rollsTable.playerId, player.id))
    .orderBy(desc(rollsTable.createdAt))
    .limit(limit);

  const formatted = rolls.map((r) => ({
    id: r.id,
    playerId: r.playerId,
    playerName: player.name,
    rollNumber: r.rollNumber,
    resultType: r.resultType,
    betAmount: r.betAmount,
    payout: r.payout,
    createdAt: r.createdAt.toISOString(),
  }));

  res.json(GetMyHistoryResponse.parse({ rolls: formatted }));
});

router.get("/game/achievements", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const player = req.player!;
  const achievements = await getPlayerAchievements(player.id);
  res.json(GetAchievementsResponse.parse({ achievements }));
});

router.get("/game/recent-winners", async (req, res): Promise<void> => {
  const limitRaw = req.query.limit ? parseInt(String(req.query.limit), 10) : 10;
  const limit = isNaN(limitRaw) ? 10 : Math.min(limitRaw, 50);

  const winners = await db
    .select({
      id: rollsTable.id,
      playerId: rollsTable.playerId,
      playerName: playersTable.name,
      rollNumber: rollsTable.rollNumber,
      resultType: rollsTable.resultType,
      betAmount: rollsTable.betAmount,
      payout: rollsTable.payout,
      createdAt: rollsTable.createdAt,
    })
    .from(rollsTable)
    .innerJoin(playersTable, eq(rollsTable.playerId, playersTable.id))
    .where(ne(rollsTable.resultType, "lose"))
    .orderBy(desc(rollsTable.createdAt))
    .limit(limit);

  const formatted = winners.map((w) => ({
    id: w.id,
    playerId: w.playerId,
    playerName: w.playerName,
    rollNumber: w.rollNumber,
    resultType: w.resultType,
    betAmount: w.betAmount,
    payout: w.payout,
    createdAt: w.createdAt.toISOString(),
  }));

  res.json(GetRecentWinnersResponse.parse({ winners: formatted }));
});

const DAILY_BONUS_AMOUNT = 100_000;
const DAILY_BONUS_INTERVAL_MS = 24 * 60 * 60 * 1000;     // 24 hours
const DAILY_BONUS_EXPIRY_MS  =  7 * 24 * 60 * 60 * 1000; // 7 days

function getDailyBonusStatus(player: typeof playersTable.$inferSelect) {
  const now = Date.now();
  const last = player.lastDailyClaimAt ? player.lastDailyClaimAt.getTime() : null;

  if (last === null) {
    // Never claimed — can claim right now
    return { canClaim: true, nextClaimAt: null, lastClaimedAt: null };
  }

  const elapsed = now - last;

  if (elapsed >= DAILY_BONUS_EXPIRY_MS) {
    // Inactive for 7+ days — fresh start, can claim now (missed days are gone)
    return { canClaim: true, nextClaimAt: null, lastClaimedAt: new Date(last).toISOString() };
  }

  if (elapsed >= DAILY_BONUS_INTERVAL_MS) {
    // 24h+ have passed — eligible
    return { canClaim: true, nextClaimAt: null, lastClaimedAt: new Date(last).toISOString() };
  }

  // Still within the 24h window — show when they can next claim
  const nextClaimAt = new Date(last + DAILY_BONUS_INTERVAL_MS).toISOString();
  return { canClaim: false, nextClaimAt, lastClaimedAt: new Date(last).toISOString() };
}

router.get("/game/daily-bonus", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  res.json(GetDailyBonusResponse.parse(getDailyBonusStatus(req.player!)));
});

router.post("/game/daily-bonus", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const status = getDailyBonusStatus(req.player!);

  if (!status.canClaim) {
    const nextAt = status.nextClaimAt ? new Date(status.nextClaimAt).toLocaleTimeString() : "";
    res.status(400).json({ error: `Already claimed today. Come back at ${nextAt}.` });
    return;
  }

  const [updated] = await db
    .update(playersTable)
    .set({
      balance: sql`${playersTable.balance} + ${DAILY_BONUS_AMOUNT}`,
      lastDailyClaimAt: new Date(),
    })
    .where(eq(playersTable.id, req.player!.id))
    .returning();

  res.json(ClaimDailyBonusResponse.parse({
    balance: updated.balance,
    message: `🎁 Daily bonus claimed! $${DAILY_BONUS_AMOUNT.toLocaleString()} added to your balance.`,
  }));
});

export default router;

import { Router, type IRouter } from "express";
import { db, playersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  LoginPlayerBody,
  LoginPlayerResponse,
  GetMeResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";

const router: IRouter = Router();

function formatPlayer(player: typeof playersTable.$inferSelect) {
  return {
    id: player.id,
    tornId: player.tornId,
    name: player.name,
    level: player.level,
    faction: player.faction,
    balance: player.balance,
    totalRolls: player.totalRolls,
    totalWon: player.totalWon,
    totalLost: player.totalLost,
    createdAt: player.createdAt.toISOString(),
  };
}

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginPlayerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { apiKey } = parsed.data;

  // Verify with Torn Public API — no selections needed for basic user info
  let tornData: { player_id: number; name: string; level: number };
  try {
    const tornRes = await fetch(`https://api.torn.com/user/?key=${apiKey}`);
    const json = (await tornRes.json()) as Record<string, unknown>;
    if ((json as { error?: { code?: number; error?: string } }).error) {
      const errObj = json.error as
        | { code?: number; error?: string }
        | undefined;
      req.log.warn({ tornError: errObj }, "Torn API returned error");
      res
        .status(401)
        .json({
          error: `Invalid API key: ${errObj?.error ?? "Unknown error"}`,
        });
      return;
    }
    tornData = json as typeof tornData;
  } catch (e) {
    req.log.error({ err: e }, "Failed to contact Torn API");
    res.status(500).json({ error: "Failed to contact Torn API" });
    return;
  }

  const tornId = tornData.player_id;
  const name = tornData.name;
  const level = tornData.level || 1;

  const existing = await db
    .select()
    .from(playersTable)
    .where(eq(playersTable.tornId, tornId));

  let player: typeof playersTable.$inferSelect;

  if (existing.length > 0) {
    const [updated] = await db
      .update(playersTable)
      .set({ name, level, apiKey })
      .where(eq(playersTable.tornId, tornId))
      .returning();
    player = updated;
  } else {
    const [created] = await db
      .insert(playersTable)
      .values({ tornId, name, level, faction: "None", apiKey, balance: 100000 })
      .returning();
    player = created;
  }

  const token = `${tornId}:${apiKey}`;
  res.json(LoginPlayerResponse.parse({ token, player: formatPlayer(player) }));
});

router.get(
  "/auth/me",
  requireAuth,
  async (req: AuthenticatedRequest, res): Promise<void> => {
    res.json(GetMeResponse.parse(formatPlayer(req.player!)));
  },
);

export default router;

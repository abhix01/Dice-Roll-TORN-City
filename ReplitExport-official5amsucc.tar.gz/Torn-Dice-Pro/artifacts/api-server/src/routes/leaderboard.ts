import { Router, type IRouter } from "express";
import { db, playersTable, rollsTable } from "@workspace/db";
import { desc, eq, max, count, sum } from "drizzle-orm";
import { GetLeaderboardResponse, GetGameStatsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/leaderboard", async (_req, res): Promise<void> => {
  // Most total won
  const mostWonRaw = await db
    .select()
    .from(playersTable)
    .orderBy(desc(playersTable.totalWon))
    .limit(10);

  // Most rolls
  const mostRollsRaw = await db
    .select()
    .from(playersTable)
    .orderBy(desc(playersTable.totalRolls))
    .limit(10);

  // Biggest single payouts per player
  const biggestJackpotsWithPlayers = await db
    .select({
      playerId: rollsTable.playerId,
      biggestPayout: max(rollsTable.payout),
      playerName: playersTable.name,
      playerLevel: playersTable.level,
      playerFaction: playersTable.faction,
      playerTornId: playersTable.tornId,
      playerTotalRolls: playersTable.totalRolls,
      playerTotalWon: playersTable.totalWon,
    })
    .from(rollsTable)
    .innerJoin(playersTable, eq(rollsTable.playerId, playersTable.id))
    .groupBy(
      rollsTable.playerId,
      playersTable.name,
      playersTable.level,
      playersTable.faction,
      playersTable.tornId,
      playersTable.totalRolls,
      playersTable.totalWon,
    )
    .orderBy(desc(max(rollsTable.payout)))
    .limit(10);

  const mostWon = mostWonRaw.map((p) => ({
    playerId: p.id,
    tornId: p.tornId,
    name: p.name,
    level: p.level,
    faction: p.faction,
    totalRolls: p.totalRolls,
    totalWon: p.totalWon,
    biggestPayout: 0,
  }));

  const mostRolls = mostRollsRaw.map((p) => ({
    playerId: p.id,
    tornId: p.tornId,
    name: p.name,
    level: p.level,
    faction: p.faction,
    totalRolls: p.totalRolls,
    totalWon: p.totalWon,
    biggestPayout: 0,
  }));

  const biggestJackpots = biggestJackpotsWithPlayers.map((r) => ({
    playerId: r.playerId,
    tornId: r.playerTornId,
    name: r.playerName,
    level: r.playerLevel,
    faction: r.playerFaction,
    totalRolls: r.playerTotalRolls,
    totalWon: r.playerTotalWon,
    biggestPayout: r.biggestPayout ?? 0,
  }));

  res.json(
    GetLeaderboardResponse.parse({
      mostWon,
      mostRolls,
      biggestJackpots,
    })
  );
});

router.get("/leaderboard/stats", async (_req, res): Promise<void> => {
  const [playerCount] = await db
    .select({ count: count() })
    .from(playersTable);

  const [rollStats] = await db
    .select({
      totalRolls: count(),
      totalPaidOut: sum(rollsTable.payout),
    })
    .from(rollsTable);

  const [jackpotCount] = await db
    .select({ count: count() })
    .from(rollsTable)
    .where(eq(rollsTable.resultType, "jackpot"));

  res.json(
    GetGameStatsResponse.parse({
      totalPlayers: playerCount.count,
      totalRolls: rollStats.totalRolls,
      totalPaidOut: parseInt(String(rollStats.totalPaidOut ?? 0), 10),
      totalJackpots: jackpotCount.count,
    })
  );
});

export default router;

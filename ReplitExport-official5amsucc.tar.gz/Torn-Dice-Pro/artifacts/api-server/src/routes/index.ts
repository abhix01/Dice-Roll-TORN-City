import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import gameRouter from "./game";
import walletRouter from "./wallet";
import leaderboardRouter from "./leaderboard";
import adminRouter from "./admin";
import playersRouter from "./players";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(gameRouter);
router.use(walletRouter);
router.use(leaderboardRouter);
router.use(adminRouter);
router.use(playersRouter);

export default router;

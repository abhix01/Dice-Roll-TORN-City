import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { db, playersTable, rollsTable, jackpotPoolTable, withdrawalRequestsTable } from "@workspace/db";
import { desc, eq, count, sum, sql } from "drizzle-orm";

const router: IRouter = Router();
const JACKPOT_SEED = 10_000_000;

function adminAuth(req: Request, res: Response, next: NextFunction): void {
  const secret = process.env.ADMIN_SECRET;
  if (!secret) { res.status(503).json({ error: "Admin panel is not configured" }); return; }
  const provided = req.headers["x-admin-secret"];
  if (provided !== secret) { res.status(401).json({ error: "Unauthorized" }); return; }
  next();
}

// GET /admin/stats
router.get("/admin/stats", adminAuth, async (_req, res): Promise<void> => {
  const [playerStats] = await db.select({ total: count() }).from(playersTable);
  const [rollStats] = await db.select({
    totalRolls: count(),
    totalPaidOut: sum(rollsTable.payout),
    totalBet: sum(rollsTable.betAmount),
  }).from(rollsTable);
  const [jackpotStats] = await db.select({ total: count() }).from(rollsTable).where(eq(rollsTable.resultType, "jackpot"));
  const [poolRow] = await db.select().from(jackpotPoolTable).limit(1);
  const [pendingWithdrawals] = await db.select({ total: count(), totalAmount: sum(withdrawalRequestsTable.amount) })
    .from(withdrawalRequestsTable).where(eq(withdrawalRequestsTable.status, "pending"));

  res.json({
    totalPlayers: playerStats.total,
    totalRolls: rollStats.totalRolls,
    totalPaidOut: parseInt(String(rollStats.totalPaidOut ?? 0), 10),
    totalBet: parseInt(String(rollStats.totalBet ?? 0), 10),
    totalJackpots: jackpotStats.total,
    jackpotPool: poolRow?.pool ?? JACKPOT_SEED,
    pendingWithdrawals: pendingWithdrawals.total,
    pendingWithdrawalAmount: parseInt(String(pendingWithdrawals.totalAmount ?? 0), 10),
  });
});

// GET /admin/players
router.get("/admin/players", adminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, parseInt(String(req.query.page ?? 1), 10));
  const limit = 20;
  const offset = (page - 1) * limit;
  const [{ total }] = await db.select({ total: count() }).from(playersTable);
  const players = await db.select().from(playersTable).orderBy(desc(playersTable.totalRolls)).limit(limit).offset(offset);
  res.json({ players, total, page, pages: Math.ceil(total / limit) });
});

// PATCH /admin/players/:id/balance
router.patch("/admin/players/:id/balance", adminAuth, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const { balance } = req.body as { balance: number };
  if (isNaN(id) || typeof balance !== "number" || balance < 0) { res.status(400).json({ error: "Invalid id or balance" }); return; }
  const [updated] = await db.update(playersTable).set({ balance }).where(eq(playersTable.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Player not found" }); return; }
  res.json(updated);
});

// DELETE /admin/players/:id/rolls
router.delete("/admin/players/:id/rolls", adminAuth, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const deleted = await db.delete(rollsTable).where(eq(rollsTable.playerId, id)).returning();
  await db.update(playersTable).set({ totalRolls: 0, totalWon: 0, totalLost: 0 }).where(eq(playersTable.id, id));
  res.json({ deleted: deleted.length });
});

// GET /admin/rolls
router.get("/admin/rolls", adminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, parseInt(String(req.query.page ?? 1), 10));
  const limit = 25;
  const offset = (page - 1) * limit;
  const [{ total }] = await db.select({ total: count() }).from(rollsTable);
  const rolls = await db
    .select({
      id: rollsTable.id, playerId: rollsTable.playerId, playerName: playersTable.name,
      rollNumber: rollsTable.rollNumber, resultType: rollsTable.resultType,
      betAmount: rollsTable.betAmount, payout: rollsTable.payout, createdAt: rollsTable.createdAt,
    })
    .from(rollsTable)
    .innerJoin(playersTable, eq(rollsTable.playerId, playersTable.id))
    .orderBy(desc(rollsTable.createdAt))
    .limit(limit).offset(offset);
  res.json({ rolls, total, page, pages: Math.ceil(total / limit) });
});

// GET /admin/withdrawals
router.get("/admin/withdrawals", adminAuth, async (req, res): Promise<void> => {
  const status = String(req.query.status ?? "pending");
  const page = Math.max(1, parseInt(String(req.query.page ?? 1), 10));
  const limit = 25;
  const offset = (page - 1) * limit;

  const [{ total }] = await db.select({ total: count() }).from(withdrawalRequestsTable)
    .where(eq(withdrawalRequestsTable.status, status));
  const requests = await db.select().from(withdrawalRequestsTable)
    .where(eq(withdrawalRequestsTable.status, status))
    .orderBy(desc(withdrawalRequestsTable.createdAt))
    .limit(limit).offset(offset);
  res.json({ requests, total, page, pages: Math.ceil(total / limit) });
});

// POST /admin/withdrawals/:id/fulfill — marks as fulfilled (you already sent Torn money)
router.post("/admin/withdrawals/:id/fulfill", adminAuth, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [existing] = await db.select().from(withdrawalRequestsTable).where(eq(withdrawalRequestsTable.id, id));
  if (!existing) { res.status(404).json({ error: "Request not found" }); return; }
  if (existing.status !== "pending") { res.status(400).json({ error: "Request is not pending" }); return; }

  const [updated] = await db.update(withdrawalRequestsTable)
    .set({ status: "fulfilled", resolvedAt: new Date() })
    .where(eq(withdrawalRequestsTable.id, id))
    .returning();
  res.json(updated);
});

// POST /admin/withdrawals/:id/cancel — cancel and refund balance to player
router.post("/admin/withdrawals/:id/cancel", adminAuth, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const { notes } = (req.body ?? {}) as { notes?: string };
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [existing] = await db.select().from(withdrawalRequestsTable).where(eq(withdrawalRequestsTable.id, id));
  if (!existing) { res.status(404).json({ error: "Request not found" }); return; }
  if (existing.status !== "pending") { res.status(400).json({ error: "Request is not pending" }); return; }

  // Refund balance
  await db.update(playersTable)
    .set({ balance: sql`${playersTable.balance} + ${existing.amount}` })
    .where(eq(playersTable.id, existing.playerId));

  const [updated] = await db.update(withdrawalRequestsTable)
    .set({ status: "cancelled", notes: notes ?? null, resolvedAt: new Date() })
    .where(eq(withdrawalRequestsTable.id, id))
    .returning();
  res.json(updated);
});

// POST /admin/jackpot/reset
router.post("/admin/jackpot/reset", adminAuth, async (_req, res): Promise<void> => {
  const rows = await db.select().from(jackpotPoolTable).limit(1);
  if (rows.length === 0) {
    const [created] = await db.insert(jackpotPoolTable).values({ pool: JACKPOT_SEED }).returning();
    res.json({ pool: created.pool }); return;
  }
  const [updated] = await db.update(jackpotPoolTable).set({ pool: JACKPOT_SEED, updatedAt: new Date() })
    .where(eq(jackpotPoolTable.id, rows[0].id)).returning();
  res.json({ pool: updated.pool });
});

// PATCH /admin/jackpot
router.patch("/admin/jackpot", adminAuth, async (req, res): Promise<void> => {
  const { pool } = req.body as { pool: number };
  if (typeof pool !== "number" || pool < 0) { res.status(400).json({ error: "Invalid pool amount" }); return; }
  const rows = await db.select().from(jackpotPoolTable).limit(1);
  if (rows.length === 0) {
    const [created] = await db.insert(jackpotPoolTable).values({ pool }).returning();
    res.json({ pool: created.pool }); return;
  }
  const [updated] = await db.update(jackpotPoolTable).set({ pool, updatedAt: new Date() })
    .where(eq(jackpotPoolTable.id, rows[0].id)).returning();
  res.json({ pool: updated.pool });
});

export default router;

import { Router, type IRouter } from "express";
import { db, playersTable, tornDepositsTable, withdrawalRequestsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { DepositResponse, TornDepositBody, WithdrawBody, WithdrawResponse } from "@workspace/api-zod";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth";

const router: IRouter = Router();

const MIN_TORN_DEPOSIT = 10_000;
const HOUSE_TORN_ID = parseInt(process.env.HOUSE_TORN_ID ?? "0", 10);
const HOUSE_API_KEY = process.env.HOUSE_API_KEY ?? "";

// POST /wallet/withdraw — deduct balance and create a pending withdrawal request
router.post("/wallet/withdraw", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const player = req.player!;
  const parsed = WithdrawBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { amount } = parsed.data;

  if (amount <= 0) { res.status(400).json({ error: "Amount must be greater than 0" }); return; }
  if (amount > player.balance) { res.status(400).json({ error: "Insufficient balance" }); return; }
  if (amount < 10_000) { res.status(400).json({ error: "Minimum withdrawal is $10,000" }); return; }

  const [updated] = await db
    .update(playersTable)
    .set({ balance: sql`${playersTable.balance} - ${amount}` })
    .where(eq(playersTable.id, player.id))
    .returning();

  await db.insert(withdrawalRequestsTable).values({
    playerId: player.id,
    tornId: player.tornId,
    playerName: player.name,
    amount,
    status: "pending",
  });

  res.json(WithdrawResponse.parse({
    balance: updated.balance,
    message: `Withdrawal of $${amount.toLocaleString()} requested. The admin will send you Torn money shortly.`,
  }));
});

// POST /wallet/torn-deposit — verify Torn in-game transfer using the HOUSE api key
router.post("/wallet/torn-deposit", requireAuth, async (req: AuthenticatedRequest, res): Promise<void> => {
  const player = req.player!;
  const parsed = TornDepositBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { amount } = parsed.data;

  if (amount < MIN_TORN_DEPOSIT) {
    res.status(400).json({ error: `Minimum deposit is $${MIN_TORN_DEPOSIT.toLocaleString()}` });
    return;
  }

  if (!HOUSE_TORN_ID || !HOUSE_API_KEY) {
    res.status(503).json({ error: "Torn deposits not configured on this server" });
    return;
  }

  // Fetch all recent logs for the house account over the last 24 hours
  const from = Math.floor(Date.now() / 1000) - 86400;
  const url = `https://api.torn.com/user/?selections=log&key=${HOUSE_API_KEY}&from=${from}`;

  let logData: Record<string, unknown>;
  try {
    const tornRes = await fetch(url);
    logData = await tornRes.json() as Record<string, unknown>;
  } catch (e) {
    req.log.error({ err: e }, "Failed to contact Torn API for deposit verification");
    res.status(500).json({ error: "Failed to contact Torn API" });
    return;
  }

  if (logData.error) {
    const tornErr = logData.error as { code?: number; error?: string } | string;
    const message = typeof tornErr === "string" ? tornErr : (tornErr.error ?? `Torn API error code ${tornErr.code}`);
    req.log.warn({ tornError: tornErr }, "Torn API returned error fetching house logs");
    res.status(500).json({ error: `Server configuration error: ${message}` });
    return;
  }

  type TornLogEntry = {
    timestamp: number;
    params?: Record<string, unknown>;
    // Torn puts the real payload in `data`, not `params`
    data?: Record<string, unknown>;
  };

  const logs = Object.entries((logData.log ?? {}) as Record<string, TornLogEntry>);
  req.log.info({ logCount: logs.length }, "Fetched house Torn log entries");

  // Match on data.sender === player.tornId AND data.money === amount
  // (Torn uses `data` for the payload, `params` is only display styling)
  const match = logs.find(([, entry]) => {
    const d = (entry.data ?? {}) as Record<string, unknown>;
    const entrySender = (d.sender as number | undefined) ?? (d.from_id as number | undefined) ?? (d.from as number | undefined);
    const entryAmount = (d.money as number | undefined) ?? (d.money_amount as number | undefined) ?? (d.amount as number | undefined);
    return entryAmount === amount && entrySender === player.tornId;
  });

  if (!match) {
    req.log.warn({ amount, playerTornId: player.tornId, logCount: logs.length }, "No matching incoming Torn log entry found");
    res.status(400).json({
      error: `No matching transfer found. Make sure you sent exactly $${amount.toLocaleString()} to Torn ID ${HOUSE_TORN_ID} within the last 24 hours.`,
    });
    return;
  }

  // Torn log IDs are alphanumeric strings (e.g. "IwGtZqbCk5NMHFWete6r")
  const tornLogId = match[0];

  const existing = await db.select().from(tornDepositsTable).where(eq(tornDepositsTable.tornLogId, tornLogId));
  if (existing.length > 0) {
    res.status(400).json({ error: "This transfer has already been credited." });
    return;
  }

  const [updated] = await db
    .update(playersTable)
    .set({ balance: sql`${playersTable.balance} + ${amount}` })
    .where(eq(playersTable.id, player.id))
    .returning();

  await db.insert(tornDepositsTable).values({ playerId: player.id, amount, tornLogId });

  res.json(DepositResponse.parse({
    balance: updated.balance,
    message: `Verified! $${amount.toLocaleString()} credited from your Torn transfer.`,
  }));
});

export default router;

import { Router, type IRouter } from "express";
import { db, playersTable, rollsTable } from "@workspace/db";
import { eq, desc, count, max, ne, and } from "drizzle-orm";
import { GetPlayerProfileResponse } from "@workspace/api-zod";
import { getPlayerAchievements } from "../lib/achievements";

const router: IRouter = Router();

router.get("/players/:tornId", async (req, res): Promise<void> => {
  const tornId = parseInt(req.params.tornId, 10);
  if (isNaN(tornId)) { res.status(400).json({ error: "Invalid tornId" }); return; }

  const [player] = await db.select().from(playersTable).where(eq(playersTable.tornId, tornId));
  if (!player) { res.status(404).json({ error: "Player not found" }); return; }

  const [recentRolls, stats, jackpotStats, wins, achievements] = await Promise.all([
    db
      .select()
      .from(rollsTable)
      .where(eq(rollsTable.playerId, player.id))
      .orderBy(desc(rollsTable.createdAt))
      .limit(30),
    db
      .select({ total: count(), biggestWin: max(rollsTable.payout) })
      .from(rollsTable)
      .where(eq(rollsTable.playerId, player.id)),
    db
      .select({ total: count() })
      .from(rollsTable)
      .where(and(eq(rollsTable.playerId, player.id), eq(rollsTable.resultType, "jackpot"))),
    db
      .select({ total: count() })
      .from(rollsTable)
      .where(and(eq(rollsTable.playerId, player.id), ne(rollsTable.resultType, "lose"))),
    getPlayerAchievements(player.id),
  ]);

  const totalRolls = stats[0].total ?? 0;
  const winRate = totalRolls > 0 ? (wins[0].total / totalRolls) : 0;

  res.json(GetPlayerProfileResponse.parse({
    player: {
      id: player.id,
      tornId: player.tornId,
      name: player.name,
      level: player.level,
      faction: player.faction,
      balance: player.balance,
      totalRolls: player.totalRolls,
      totalWon: player.totalWon,
      totalLost: player.totalLost,
      createdAt: player.createdAt.toISOString(),
    },
    recentRolls: recentRolls.map((r) => ({
      id: r.id,
      playerId: r.playerId,
      playerName: player.name,
      rollNumber: r.rollNumber,
      resultType: r.resultType,
      betAmount: r.betAmount,
      payout: r.payout,
      createdAt: r.createdAt.toISOString(),
    })),
    winRate,
    biggestWin: stats[0].biggestWin ?? 0,
    jackpotsHit: jackpotStats[0].total,
    achievements,
  }));
});

export default router;

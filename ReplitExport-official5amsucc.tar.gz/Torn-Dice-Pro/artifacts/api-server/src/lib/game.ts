export type ResultType = "lose" | "small_win" | "big_win" | "jackpot";

// Bets above this threshold are eligible for the jackpot (99-100)
export const JACKPOT_MIN_BET = 100_000;

// Thresholds (inclusive upper bounds):
//  1–60  → lose        (60% chance)
// 61–90  → small_win   (30% chance) → 1.4× payout  (net +0.4×)
// 91–98  → big_win     ( 8% chance) → 3×  payout  (net +2×)
// 99–100 → jackpot     ( 2% chance) → entire pool  [only for bets > JACKPOT_MIN_BET]
//           if bet ≤ JACKPOT_MIN_BET, 99-100 also resolves as big_win (10% big_win total)
export function calculateResult(
  rollNumber: number,
  betAmount: number,
): { resultType: ResultType; payout: number } {
  if (rollNumber <= 60) {
    return { resultType: "lose", payout: 0 };
  }
  if (rollNumber <= 90) {
    return { resultType: "small_win", payout: Math.floor(betAmount * 1.4) };
  }
  // 91–100 → big_win (caller handles jackpot separately for eligible bets)
  return { resultType: "big_win", payout: betAmount * 3 };
}

export function generateRollNumber(): number {
  return Math.floor(Math.random() * 100) + 1;
}

import { db, playerAchievementsTable, rollsTable } from "@workspace/db";
import { eq, count, sum, and, gt } from "drizzle-orm";

export type AchievementDef = {
  id: string;
  name: string;
  description: string;
  emoji: string;
};

export const ACHIEVEMENT_DEFS: Record<string, AchievementDef> = {
  first_win: {
    id: "first_win",
    name: "First Win",
    description: "Win your very first dice roll",
    emoji: "🎲",
  },
  first_jackpot: {
    id: "first_jackpot",
    name: "Jackpot!",
    description: "Hit the jackpot for the first time",
    emoji: "⚡",
  },
  centurion: {
    id: "centurion",
    name: "Centurion",
    description: "Place 100 dice rolls",
    emoji: "🎰",
  },
  veteran: {
    id: "veteran",
    name: "Veteran",
    description: "Place 500 dice rolls",
    emoji: "🏆",
  },
  all_in: {
    id: "all_in",
    name: "All In",
    description: "Bet $10M in a single roll",
    emoji: "💸",
  },
  high_roller: {
    id: "high_roller",
    name: "High Roller",
    description: "Wager $10M total across all rolls",
    emoji: "💰",
  },
  whale: {
    id: "whale",
    name: "Whale",
    description: "Wager $100M total across all rolls",
    emoji: "🐋",
  },
  jackpot_hunter: {
    id: "jackpot_hunter",
    name: "Jackpot Hunter",
    description: "Place 100 jackpot-eligible rolls (bet > $100K)",
    emoji: "🎯",
  },
};

export type RollContext = {
  resultType: string;
  betAmount: number;
  totalRolls: number;
};

export async function checkAndAwardAchievements(
  playerId: number,
  roll: RollContext,
): Promise<AchievementDef[]> {
  // Fetch already-earned achievement IDs
  const earned = await db
    .select({ achievementId: playerAchievementsTable.achievementId })
    .from(playerAchievementsTable)
    .where(eq(playerAchievementsTable.playerId, playerId));
  const earnedIds = new Set(earned.map((e) => e.achievementId));

  const toAward: string[] = [];

  // first_win
  if (!earnedIds.has("first_win") && roll.resultType !== "lose") {
    toAward.push("first_win");
  }

  // first_jackpot
  if (!earnedIds.has("first_jackpot") && roll.resultType === "jackpot") {
    toAward.push("first_jackpot");
  }

  // centurion: 100 rolls
  if (!earnedIds.has("centurion") && roll.totalRolls >= 100) {
    toAward.push("centurion");
  }

  // veteran: 500 rolls
  if (!earnedIds.has("veteran") && roll.totalRolls >= 500) {
    toAward.push("veteran");
  }

  // all_in: bet $10M in one roll
  if (!earnedIds.has("all_in") && roll.betAmount >= 10_000_000) {
    toAward.push("all_in");
  }

  // high_roller: $10M total wagered — query the rolls table
  if (!earnedIds.has("high_roller") || !earnedIds.has("whale")) {
    const [betStats] = await db
      .select({ total: sum(rollsTable.betAmount) })
      .from(rollsTable)
      .where(eq(rollsTable.playerId, playerId));
    const totalBet = parseInt(String(betStats.total ?? 0), 10);
    if (!earnedIds.has("high_roller") && totalBet >= 10_000_000) {
      toAward.push("high_roller");
    }
    if (!earnedIds.has("whale") && totalBet >= 100_000_000) {
      toAward.push("whale");
    }
  }

  // jackpot_hunter: 100 jackpot-eligible rolls (bet > $100K)
  if (!earnedIds.has("jackpot_hunter")) {
    const [jStats] = await db
      .select({ total: count() })
      .from(rollsTable)
      .where(and(eq(rollsTable.playerId, playerId), gt(rollsTable.betAmount, 100_000)));
    if (jStats.total >= 100) {
      toAward.push("jackpot_hunter");
    }
  }

  if (toAward.length > 0) {
    await db
      .insert(playerAchievementsTable)
      .values(toAward.map((id) => ({ playerId, achievementId: id })))
      .onConflictDoNothing();
  }

  return toAward.map((id) => ACHIEVEMENT_DEFS[id]).filter(Boolean);
}

export async function getPlayerAchievements(playerId: number): Promise<(AchievementDef & { earnedAt: string })[]> {
  const rows = await db
    .select()
    .from(playerAchievementsTable)
    .where(eq(playerAchievementsTable.playerId, playerId))
    .orderBy(playerAchievementsTable.earnedAt);

  return rows
    .map((r) => {
      const def = ACHIEVEMENT_DEFS[r.achievementId];
      if (!def) return null;
      return { ...def, earnedAt: r.earnedAt.toISOString() };
    })
    .filter((x): x is AchievementDef & { earnedAt: string } => x !== null);
}

import type { Request, Response, NextFunction } from "express";
import { db, playersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

export interface AuthenticatedRequest extends Request {
  player?: typeof playersTable.$inferSelect;
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const token = req.headers["x-player-token"];
  if (!token || typeof token !== "string") {
    res.status(401).json({ error: "Missing player token" });
    return;
  }

  // Token is "tornId:apiKey"
  const parts = token.split(":");
  if (parts.length < 2) {
    res.status(401).json({ error: "Invalid token format" });
    return;
  }

  const tornId = parseInt(parts[0], 10);
  const apiKey = parts.slice(1).join(":");

  if (isNaN(tornId)) {
    res.status(401).json({ error: "Invalid token" });
    return;
  }

  const [player] = await db
    .select()
    .from(playersTable)
    .where(eq(playersTable.tornId, tornId));

  if (!player || player.apiKey !== apiKey) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  req.player = player;
  next();
}

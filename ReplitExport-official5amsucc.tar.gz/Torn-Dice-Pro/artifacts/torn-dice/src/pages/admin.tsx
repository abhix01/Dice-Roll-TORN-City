import { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users, Scroll, Trophy, TrendingUp, RefreshCw,
  Lock, Edit2, Trash2, ChevronLeft, ChevronRight, AlertCircle, Check,
  ArrowUpCircle, CheckCircle2, XCircle, Clock
} from "lucide-react";
import { cn } from "@/lib/utils";

const BASE = "/api";

function fmt(n: number) {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

type Stats = {
  totalPlayers: number; totalRolls: number; totalPaidOut: number;
  totalBet: number; totalJackpots: number; jackpotPool: number;
  pendingWithdrawals: number; pendingWithdrawalAmount: number;
};
type Player = {
  id: number; tornId: number; name: string; level: number; faction: string;
  balance: number; totalRolls: number; totalWon: number; totalLost: number; createdAt: string;
};
type Roll = {
  id: number; playerId: number; playerName: string; rollNumber: number;
  resultType: string; betAmount: number; payout: number; createdAt: string;
};
type WithdrawalRequest = {
  id: number; playerId: number; tornId: number; playerName: string;
  amount: number; status: string; notes: string | null; createdAt: string; resolvedAt: string | null;
};

export function Admin() {
  const [secret, setSecret] = useState(() => localStorage.getItem("admin_secret") ?? "");
  const [authed, setAuthed] = useState(false);
  const [authError, setAuthError] = useState("");
  const [tab, setTab] = useState<"overview" | "withdrawals" | "players" | "rolls" | "jackpot">("overview");

  const [stats, setStats] = useState<Stats | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [playerPage, setPlayerPage] = useState(1);
  const [playerPages, setPlayerPages] = useState(1);
  const [rolls, setRolls] = useState<Roll[]>([]);
  const [rollPage, setRollPage] = useState(1);
  const [rollPages, setRollPages] = useState(1);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [withdrawalFilter, setWithdrawalFilter] = useState<"pending" | "fulfilled" | "cancelled">("pending");
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editBalance, setEditBalance] = useState("");
  const [jackpotInput, setJackpotInput] = useState("");
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const headers = { "x-admin-secret": secret, "Content-Type": "application/json" };

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  const apiFetch = useCallback(async (path: string, opts?: RequestInit) => {
    const r = await fetch(`${BASE}${path}`, { ...opts, headers: { ...headers, ...(opts?.headers ?? {}) } });
    if (!r.ok) {
      const j = await r.json().catch(() => ({})) as { error?: string };
      throw new Error(j.error ?? r.statusText);
    }
    return r.json();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secret]);

  const tryAuth = async () => {
    try {
      const data = await apiFetch("/admin/stats") as Stats;
      setStats(data);
      setAuthed(true);
      localStorage.setItem("admin_secret", secret);
    } catch (e) {
      setAuthError((e as Error).message);
    }
  };

  const loadStats = useCallback(async () => {
    const data = await apiFetch("/admin/stats") as Stats;
    setStats(data);
  }, [apiFetch]);

  const loadPlayers = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const data = await apiFetch(`/admin/players?page=${page}`) as { players: Player[]; pages: number; page: number };
      setPlayers(data.players); setPlayerPages(data.pages); setPlayerPage(data.page);
    } finally { setLoading(false); }
  }, [apiFetch]);

  const loadRolls = useCallback(async (page = 1) => {
    setLoading(true);
    try {
      const data = await apiFetch(`/admin/rolls?page=${page}`) as { rolls: Roll[]; pages: number; page: number };
      setRolls(data.rolls); setRollPages(data.pages); setRollPage(data.page);
    } finally { setLoading(false); }
  }, [apiFetch]);

  const loadWithdrawals = useCallback(async (status = withdrawalFilter) => {
    setLoading(true);
    try {
      const data = await apiFetch(`/admin/withdrawals?status=${status}`) as { requests: WithdrawalRequest[] };
      setWithdrawals(data.requests);
    } finally { setLoading(false); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiFetch, withdrawalFilter]);

  useEffect(() => {
    if (!authed) return;
    if (tab === "overview") loadStats();
    if (tab === "players") loadPlayers(playerPage);
    if (tab === "rolls") loadRolls(rollPage);
    if (tab === "withdrawals") loadWithdrawals(withdrawalFilter);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authed, tab]);

  useEffect(() => {
    if (authed && tab === "withdrawals") loadWithdrawals(withdrawalFilter);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [withdrawalFilter]);

  const saveBalance = async (id: number) => {
    const balance = parseInt(editBalance.replace(/[^0-9]/g, ""), 10);
    if (isNaN(balance)) return;
    try {
      await apiFetch(`/admin/players/${id}/balance`, { method: "PATCH", body: JSON.stringify({ balance }) });
      setPlayers((prev) => prev.map((p) => p.id === id ? { ...p, balance } : p));
      setEditingId(null);
      showToast("Balance updated");
    } catch (e) { showToast((e as Error).message, false); }
  };

  const clearRolls = async (id: number, name: string) => {
    if (!confirm(`Clear ALL rolls for ${name}? This resets their stats.`)) return;
    try {
      await apiFetch(`/admin/players/${id}/rolls`, { method: "DELETE" });
      setPlayers((prev) => prev.map((p) => p.id === id ? { ...p, totalRolls: 0, totalWon: 0, totalLost: 0 } : p));
      showToast(`Rolls cleared for ${name}`);
    } catch (e) { showToast((e as Error).message, false); }
  };

  const fulfillWithdrawal = async (id: number, playerName: string, amount: number) => {
    if (!confirm(`Mark withdrawal fulfilled?\n\n${playerName} — ${fmt(amount)}\n\nThis means you have already sent them Torn money.`)) return;
    try {
      await apiFetch(`/admin/withdrawals/${id}/fulfill`, { method: "POST" });
      setWithdrawals((prev) => prev.filter((w) => w.id !== id));
      setStats((s) => s ? { ...s, pendingWithdrawals: s.pendingWithdrawals - 1, pendingWithdrawalAmount: s.pendingWithdrawalAmount - amount } : s);
      showToast(`Fulfilled — ${fmt(amount)} sent to ${playerName}`);
    } catch (e) { showToast((e as Error).message, false); }
  };

  const cancelWithdrawal = async (id: number, playerName: string, amount: number) => {
    if (!confirm(`Cancel this withdrawal and refund ${fmt(amount)} to ${playerName}'s balance?`)) return;
    try {
      await apiFetch(`/admin/withdrawals/${id}/cancel`, { method: "POST", body: JSON.stringify({ notes: "Cancelled by admin" }) });
      setWithdrawals((prev) => prev.filter((w) => w.id !== id));
      setStats((s) => s ? { ...s, pendingWithdrawals: s.pendingWithdrawals - 1, pendingWithdrawalAmount: s.pendingWithdrawalAmount - amount } : s);
      showToast(`Cancelled — ${fmt(amount)} refunded to ${playerName}`);
    } catch (e) { showToast((e as Error).message, false); }
  };

  const resetJackpot = async () => {
    if (!confirm("Reset jackpot pool to $10M?")) return;
    try {
      const data = await apiFetch("/admin/jackpot/reset", { method: "POST" }) as { pool: number };
      setStats((s) => s ? { ...s, jackpotPool: data.pool } : s);
      showToast("Jackpot reset to $10M");
    } catch (e) { showToast((e as Error).message, false); }
  };

  const setJackpot = async () => {
    const pool = parseInt(jackpotInput.replace(/[^0-9]/g, ""), 10);
    if (isNaN(pool) || pool < 0) return;
    try {
      const data = await apiFetch("/admin/jackpot", { method: "PATCH", body: JSON.stringify({ pool }) }) as { pool: number };
      setStats((s) => s ? { ...s, jackpotPool: data.pool } : s);
      setJackpotInput("");
      showToast(`Jackpot set to ${fmt(data.pool)}`);
    } catch (e) { showToast((e as Error).message, false); }
  };

  const resultColor = (r: string) =>
    r === "jackpot" ? "text-yellow-400" : r === "big_win" ? "text-secondary" : r === "small_win" ? "text-green-400" : "text-destructive";

  if (!authed) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-sm border-border bg-card/80 backdrop-blur-xl">
          <CardContent className="p-8 space-y-6">
            <div className="flex flex-col items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Lock className="w-6 h-6 text-primary" />
              </div>
              <div className="text-center">
                <div className="font-black uppercase tracking-widest text-lg">Admin Panel</div>
                <div className="text-xs text-muted-foreground font-mono mt-0.5">Restricted access</div>
              </div>
            </div>
            {authError && (
              <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded px-3 py-2">
                <AlertCircle className="w-3 h-3 shrink-0" /> {authError}
              </div>
            )}
            <div className="space-y-3">
              <Input type="password" placeholder="Admin secret" value={secret}
                onChange={(e) => { setSecret(e.target.value); setAuthError(""); }}
                onKeyDown={(e) => e.key === "Enter" && tryAuth()}
                className="font-mono bg-background/50 border-border" />
              <Button onClick={tryAuth} className="w-full bg-primary text-primary-foreground font-bold uppercase tracking-wider">
                Enter
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const TABS = [
    { id: "overview", label: "Overview", icon: TrendingUp },
    { id: "withdrawals", label: "Withdrawals", icon: ArrowUpCircle, badge: stats?.pendingWithdrawals },
    { id: "players", label: "Players", icon: Users },
    { id: "rolls", label: "Rolls", icon: Scroll },
    { id: "jackpot", label: "Jackpot", icon: Trophy },
  ] as const;

  return (
    <div className="flex-1 space-y-6">
      {toast && (
        <div className={cn(
          "fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-mono shadow-xl animate-in slide-in-from-bottom-4",
          toast.ok ? "bg-green-950 border-green-500/40 text-green-400" : "bg-destructive/20 border-destructive/40 text-destructive"
        )}>
          {toast.ok ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <div className="font-black uppercase tracking-widest text-xl text-primary">Admin Panel</div>
          <div className="text-xs text-muted-foreground font-mono">Torn Dice Roll — management console</div>
        </div>
        <Button variant="ghost" size="sm" onClick={loadStats} className="text-muted-foreground hover:text-primary">
          <RefreshCw className="w-4 h-4" />
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted/30 p-1 rounded-lg overflow-x-auto">
        {TABS.map(({ id, label, icon: Icon, badge }) => (
          <button key={id} onClick={() => setTab(id as typeof tab)}
            className={cn("flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-xs font-mono font-bold uppercase tracking-wider transition-colors whitespace-nowrap relative min-w-fit",
              tab === id ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}>
            <Icon className="w-3.5 h-3.5" /> {label}
            {badge && badge > 0 ? (
              <span className="absolute -top-1 -right-1 w-4 h-4 text-[9px] font-black bg-destructive text-white rounded-full flex items-center justify-center">
                {badge}
              </span>
            ) : null}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab === "overview" && (
        <div className="space-y-4">
          {!stats ? <Skeleton className="h-48 w-full" /> : (
            <>
              {/* Pending withdrawals alert */}
              {stats.pendingWithdrawals > 0 && (
                <div className="flex items-center gap-3 p-4 rounded-xl border border-destructive/30 bg-destructive/10 cursor-pointer hover:bg-destructive/15 transition-colors"
                  onClick={() => setTab("withdrawals")}>
                  <Clock className="w-5 h-5 text-destructive shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-destructive text-sm">
                      {stats.pendingWithdrawals} pending withdrawal{stats.pendingWithdrawals !== 1 ? "s" : ""}
                    </div>
                    <div className="text-xs text-muted-foreground font-mono">
                      Total owed: <span className="text-destructive font-bold">{fmt(stats.pendingWithdrawalAmount)}</span> — click to manage
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { label: "Players", value: stats.totalPlayers.toLocaleString(), color: "text-primary" },
                  { label: "Total Rolls", value: stats.totalRolls.toLocaleString(), color: "text-foreground" },
                  { label: "Total Paid Out", value: fmt(stats.totalPaidOut), color: "text-green-400" },
                  { label: "Total Bet", value: fmt(stats.totalBet), color: "text-muted-foreground" },
                  { label: "Jackpots Hit", value: stats.totalJackpots.toLocaleString(), color: "text-yellow-400" },
                  { label: "Jackpot Pool", value: fmt(stats.jackpotPool), color: "text-yellow-300" },
                ].map(({ label, value, color }) => (
                  <Card key={label} className="border-border bg-card/60">
                    <CardContent className="p-4">
                      <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
                      <div className={cn("text-xl font-black font-mono tabular-nums", color)}>{value}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="border-border bg-card/60">
                <CardContent className="p-4 space-y-2">
                  <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-3">House Edge</div>
                  <div className="flex justify-between text-sm font-mono">
                    <span className="text-muted-foreground">Total wagered</span>
                    <span className="text-foreground font-bold">{fmt(stats.totalBet)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-mono">
                    <span className="text-muted-foreground">Total paid out</span>
                    <span className="text-green-400 font-bold">{fmt(stats.totalPaidOut)}</span>
                  </div>
                  <div className="h-px bg-border my-1" />
                  <div className="flex justify-between text-sm font-mono">
                    <span className="text-muted-foreground">House profit</span>
                    <span className={cn("font-bold", stats.totalBet - stats.totalPaidOut >= 0 ? "text-primary" : "text-destructive")}>
                      {fmt(stats.totalBet - stats.totalPaidOut)}
                    </span>
                  </div>
                  {stats.totalBet > 0 && (
                    <div className="flex justify-between text-sm font-mono">
                      <span className="text-muted-foreground">Edge %</span>
                      <span className="text-primary font-bold">
                        {(((stats.totalBet - stats.totalPaidOut) / stats.totalBet) * 100).toFixed(1)}%
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      )}

      {/* WITHDRAWALS */}
      {tab === "withdrawals" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex gap-1 bg-muted/30 p-1 rounded-lg">
              {(["pending", "fulfilled", "cancelled"] as const).map((s) => (
                <button key={s} onClick={() => setWithdrawalFilter(s)}
                  className={cn("px-3 py-1.5 text-xs font-mono font-bold uppercase tracking-wider rounded-md transition-colors",
                    withdrawalFilter === s ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
                  )}>
                  {s}
                </button>
              ))}
            </div>
            <Button size="sm" variant="ghost" onClick={() => loadWithdrawals(withdrawalFilter)} className="text-muted-foreground hover:text-primary">
              <RefreshCw className="w-3.5 h-3.5" />
            </Button>
          </div>

          {withdrawalFilter === "pending" && withdrawals.length > 0 && (
            <div className="flex items-center gap-2 text-xs font-mono text-destructive bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2">
              <Clock className="w-3.5 h-3.5 shrink-0" />
              {withdrawals.length} pending — send Torn money to each player then click Fulfill
            </div>
          )}

          {loading ? <Skeleton className="h-64 w-full" /> : withdrawals.length === 0 ? (
            <Card className="border-border bg-card/60">
              <CardContent className="p-12 text-center text-muted-foreground font-mono text-sm">
                No {withdrawalFilter} withdrawal requests
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {withdrawals.map((w) => (
                <Card key={w.id} className={cn("border-border bg-card/60", w.status === "pending" ? "border-destructive/20" : "")}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-foreground">{w.playerName}</span>
                        <span className="text-xs font-mono text-muted-foreground">Torn ID: {w.tornId}</span>
                        <span className={cn("text-[10px] font-mono uppercase font-bold px-1.5 py-0.5 rounded",
                          w.status === "pending" ? "bg-destructive/20 text-destructive" :
                          w.status === "fulfilled" ? "bg-green-500/20 text-green-400" :
                          "bg-muted text-muted-foreground"
                        )}>{w.status}</span>
                      </div>
                      <div className="text-xl font-black font-mono text-foreground">{fmt(w.amount)}</div>
                      <div className="text-xs text-muted-foreground font-mono">
                        Requested {timeAgo(w.createdAt)}
                        {w.resolvedAt && ` · Resolved ${timeAgo(w.resolvedAt)}`}
                      </div>
                    </div>
                    {w.status === "pending" && (
                      <div className="flex flex-col gap-2 shrink-0">
                        <Button size="sm"
                          onClick={() => fulfillWithdrawal(w.id, w.playerName, w.amount)}
                          className="bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 font-bold text-xs h-8 gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Fulfilled
                        </Button>
                        <Button size="sm"
                          onClick={() => cancelWithdrawal(w.id, w.playerName, w.amount)}
                          className="bg-destructive/10 text-destructive border border-destructive/20 hover:bg-destructive/20 font-bold text-xs h-8 gap-1.5">
                          <XCircle className="w-3.5 h-3.5" /> Cancel & Refund
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PLAYERS */}
      {tab === "players" && (
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <div className="text-xs font-mono text-muted-foreground">{players.length} players shown</div>
            <Button size="sm" variant="ghost" onClick={() => loadPlayers(playerPage)} className="text-muted-foreground hover:text-primary">
              <RefreshCw className="w-3.5 h-3.5" />
            </Button>
          </div>
          {loading ? <Skeleton className="h-64 w-full" /> : (
            <Card className="border-border bg-card/60 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/20 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                      <th className="text-left p-3">Player</th>
                      <th className="text-right p-3">Balance</th>
                      <th className="text-right p-3">Rolls</th>
                      <th className="text-right p-3">Won</th>
                      <th className="text-right p-3">Losses</th>
                      <th className="text-right p-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {players.map((p) => (
                      <tr key={p.id} className="hover:bg-muted/10 transition-colors">
                        <td className="p-3">
                          <div className="font-bold text-foreground">{p.name}</div>
                          <div className="text-xs text-muted-foreground font-mono">[{p.tornId}] Lv{p.level}</div>
                        </td>
                        <td className="p-3 text-right font-mono">
                          {editingId === p.id ? (
                            <div className="flex items-center gap-1 justify-end">
                              <Input value={editBalance} onChange={(e) => setEditBalance(e.target.value)}
                                onKeyDown={(e) => { if (e.key === "Enter") saveBalance(p.id); if (e.key === "Escape") setEditingId(null); }}
                                className="w-28 h-7 text-xs font-mono p-1 bg-background/50" autoFocus />
                              <Button size="sm" className="h-7 px-2 text-xs" onClick={() => saveBalance(p.id)}>✓</Button>
                            </div>
                          ) : (
                            <span className="text-foreground">{fmt(p.balance)}</span>
                          )}
                        </td>
                        <td className="p-3 text-right font-mono text-muted-foreground">{p.totalRolls.toLocaleString()}</td>
                        <td className="p-3 text-right font-mono text-green-400">{fmt(p.totalWon)}</td>
                        <td className="p-3 text-right font-mono text-destructive">{p.totalLost.toLocaleString()}</td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-primary"
                              onClick={() => { setEditingId(p.id); setEditBalance(String(p.balance)); }}>
                              <Edit2 className="w-3 h-3" />
                            </Button>
                            <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive"
                              onClick={() => clearRolls(p.id, p.name)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
          {playerPages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <Button size="sm" variant="ghost" disabled={playerPage <= 1} onClick={() => loadPlayers(playerPage - 1)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-xs font-mono text-muted-foreground">Page {playerPage} / {playerPages}</span>
              <Button size="sm" variant="ghost" disabled={playerPage >= playerPages} onClick={() => loadPlayers(playerPage + 1)}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      )}

      {/* ROLLS */}
      {tab === "rolls" && (
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <div className="text-xs font-mono text-muted-foreground">{rolls.length} rolls shown</div>
            <Button size="sm" variant="ghost" onClick={() => loadRolls(rollPage)} className="text-muted-foreground hover:text-primary">
              <RefreshCw className="w-3.5 h-3.5" />
            </Button>
          </div>
          {loading ? <Skeleton className="h-64 w-full" /> : (
            <Card className="border-border bg-card/60 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/20 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                      <th className="text-left p-3">Player</th>
                      <th className="text-right p-3">Roll</th>
                      <th className="text-right p-3">Result</th>
                      <th className="text-right p-3">Bet</th>
                      <th className="text-right p-3">Payout</th>
                      <th className="text-right p-3">When</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {rolls.map((r) => (
                      <tr key={r.id} className={cn("hover:bg-muted/10 transition-colors", r.resultType === "jackpot" ? "bg-yellow-950/10" : "")}>
                        <td className="p-3 font-bold text-foreground">{r.playerName}</td>
                        <td className="p-3 text-right font-mono font-bold">{r.rollNumber}</td>
                        <td className={cn("p-3 text-right font-mono font-bold uppercase text-xs", resultColor(r.resultType))}>
                          {r.resultType.replace("_", " ")}
                        </td>
                        <td className="p-3 text-right font-mono text-muted-foreground">{fmt(r.betAmount)}</td>
                        <td className={cn("p-3 text-right font-mono font-bold", r.payout > 0 ? "text-green-400" : "text-destructive")}>
                          {r.payout > 0 ? fmt(r.payout) : "-"}
                        </td>
                        <td className="p-3 text-right text-xs font-mono text-muted-foreground">{timeAgo(r.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
          {rollPages > 1 && (
            <div className="flex items-center justify-center gap-3">
              <Button size="sm" variant="ghost" disabled={rollPage <= 1} onClick={() => loadRolls(rollPage - 1)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-xs font-mono text-muted-foreground">Page {rollPage} / {rollPages}</span>
              <Button size="sm" variant="ghost" disabled={rollPage >= rollPages} onClick={() => loadRolls(rollPage + 1)}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      )}

      {/* JACKPOT */}
      {tab === "jackpot" && (
        <div className="space-y-4 max-w-md">
          <Card className="border-yellow-500/30 bg-yellow-950/20">
            <CardContent className="p-6 text-center space-y-2">
              <div className="text-xs font-mono uppercase tracking-widest text-yellow-600">Current Pool</div>
              <div className="text-4xl font-black font-mono text-yellow-300 drop-shadow-[0_0_12px_rgba(253,224,71,0.5)]">
                {stats ? fmt(stats.jackpotPool) : "—"}
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card/60">
            <CardContent className="p-5 space-y-4">
              <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Set Pool Amount</div>
              <div className="flex gap-2">
                <Input type="text" placeholder="e.g. 50000000" value={jackpotInput}
                  onChange={(e) => setJackpotInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && setJackpot()}
                  className="font-mono bg-background/50 border-border flex-1" />
                <Button onClick={setJackpot} className="bg-primary text-primary-foreground font-bold px-4">Set</Button>
              </div>
              <div className="flex gap-2 flex-wrap">
                {[10_000_000, 50_000_000, 100_000_000, 500_000_000].map((v) => (
                  <button key={v} onClick={() => setJackpotInput(String(v))}
                    className="px-3 py-1.5 text-xs font-mono rounded border border-border text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors">
                    {fmt(v)}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card className="border-destructive/20 bg-destructive/5">
            <CardContent className="p-5 space-y-3">
              <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Danger Zone</div>
              <div className="text-xs text-muted-foreground font-mono">Reset the jackpot pool back to the starting amount of $10M.</div>
              <Button onClick={resetJackpot} variant="outline"
                className="border-destructive/30 text-destructive hover:bg-destructive/10 font-bold w-full">
                Reset Pool to $10M
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

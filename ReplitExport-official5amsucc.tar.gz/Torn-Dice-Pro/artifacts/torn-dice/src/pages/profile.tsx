import { useParams, useLocation } from "wouter";
import { useGetPlayerProfile } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trophy, Dice5, TrendingUp, Zap, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

function fmt(n: number) {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

const resultColor = (r: string) => {
  switch (r) {
    case "lose": return "text-destructive";
    case "small_win": return "text-green-400";
    case "big_win": return "text-secondary";
    case "jackpot": return "text-yellow-400";
    default: return "text-muted-foreground";
  }
};

const ACHIEVEMENT_COLORS: Record<string, string> = {
  first_win:       "border-green-500/40 bg-green-950/30 text-green-300",
  first_jackpot:   "border-yellow-500/40 bg-yellow-950/30 text-yellow-300",
  centurion:       "border-blue-500/40 bg-blue-950/30 text-blue-300",
  veteran:         "border-purple-500/40 bg-purple-950/30 text-purple-300",
  all_in:          "border-red-500/40 bg-red-950/30 text-red-300",
  high_roller:     "border-amber-500/40 bg-amber-950/30 text-amber-300",
  whale:           "border-cyan-500/40 bg-cyan-950/30 text-cyan-300",
  jackpot_hunter:  "border-orange-500/40 bg-orange-950/30 text-orange-300",
};

export function Profile() {
  const { tornId } = useParams<{ tornId: string }>();
  const [, setLocation] = useLocation();
  const { data, isLoading, isError } = useGetPlayerProfile(parseInt(tornId ?? "0", 10));

  if (isError) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center">
        <div className="text-4xl font-black text-muted-foreground">404</div>
        <div className="text-muted-foreground font-mono">Player not found</div>
        <Button variant="ghost" onClick={() => setLocation("/leaderboard")} className="text-primary">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to leaderboard
        </Button>
      </div>
    );
  }

  const achievements = data?.achievements ?? [];

  return (
    <div className="space-y-6 max-w-3xl mx-auto animate-in fade-in duration-500">
      <Button variant="ghost" size="sm" onClick={() => setLocation("/leaderboard")}
        className="text-muted-foreground hover:text-primary -ml-2">
        <ArrowLeft className="w-4 h-4 mr-1.5" /> Leaderboard
      </Button>

      {/* Header */}
      {isLoading ? <Skeleton className="h-28 w-full rounded-xl" /> : data && (
        <Card className="border-border bg-card/60 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/0 via-primary to-primary/0" />
          <CardContent className="p-6 flex flex-wrap items-center gap-6">
            <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center shrink-0">
              <Dice5 className="w-8 h-8 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-2xl font-black truncate">{data.player.name}</div>
              <div className="text-sm text-muted-foreground font-mono">
                Torn ID: {data.player.tornId} · Lv {data.player.level}
              </div>
              <div className="text-xs text-muted-foreground font-mono mt-0.5">
                Member since {format(new Date(data.player.createdAt), "MMM d, yyyy")}
              </div>
            </div>
            {achievements.length > 0 && (
              <div className="flex items-center gap-1 shrink-0">
                {achievements.slice(0, 5).map((a) => (
                  <span key={a.id} title={a.name} className="text-xl">{a.emoji}</span>
                ))}
                {achievements.length > 5 && (
                  <span className="text-xs font-mono text-muted-foreground ml-1">+{achievements.length - 5}</span>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Stats grid */}
      {isLoading ? <Skeleton className="h-32 w-full rounded-xl" /> : data && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Total Rolls", value: data.player.totalRolls.toLocaleString(), icon: Dice5, color: "text-primary" },
            { label: "Total Won", value: fmt(data.player.totalWon), icon: TrendingUp, color: "text-green-400" },
            { label: "Win Rate", value: `${(data.winRate * 100).toFixed(1)}%`, icon: Trophy, color: "text-secondary" },
            { label: "Jackpots", value: data.jackpotsHit.toLocaleString(), icon: Zap, color: "text-yellow-400" },
          ].map(({ label, value, icon: Icon, color }) => (
            <Card key={label} className="border-border bg-card/50">
              <CardContent className="p-4">
                <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
                  <Icon className={cn("w-3.5 h-3.5", color)} />
                  <span className="text-[10px] font-mono uppercase tracking-wider">{label}</span>
                </div>
                <div className={cn("text-xl font-black font-mono tabular-nums", color)}>{value}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Biggest win callout */}
      {data && data.biggestWin > 0 && (
        <div className="flex items-center gap-3 rounded-xl border border-yellow-500/20 bg-yellow-950/20 px-5 py-3">
          <Trophy className="w-5 h-5 text-yellow-400 shrink-0" />
          <div className="text-sm font-mono">
            <span className="text-muted-foreground">Biggest win: </span>
            <span className="text-yellow-300 font-bold">{fmt(data.biggestWin)}</span>
          </div>
        </div>
      )}

      {/* Achievements / Badges */}
      {isLoading ? <Skeleton className="h-32 w-full rounded-xl" /> : (
        <Card className="border-border bg-card/60 overflow-hidden">
          <div className="p-4 border-b border-border bg-muted/20 flex items-center gap-2">
            <Star className="w-4 h-4 text-primary" />
            <h3 className="font-bold uppercase tracking-wider text-sm">Achievements</h3>
            {achievements.length > 0 && (
              <span className="ml-auto text-xs font-mono text-muted-foreground">{achievements.length} earned</span>
            )}
          </div>
          {achievements.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground font-mono text-sm">
              No achievements yet — keep rolling!
            </div>
          ) : (
            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {achievements.map((a) => (
                <div
                  key={a.id}
                  className={cn(
                    "flex items-start gap-3 p-3 rounded-lg border",
                    ACHIEVEMENT_COLORS[a.id] ?? "border-border bg-muted/20 text-foreground"
                  )}
                >
                  <span className="text-2xl shrink-0 leading-none mt-0.5">{a.emoji}</span>
                  <div className="min-w-0">
                    <div className="font-bold text-sm leading-tight">{a.name}</div>
                    <div className="text-xs opacity-70 leading-tight mt-0.5">{a.description}</div>
                    <div className="text-[10px] font-mono opacity-50 mt-1">
                      {format(new Date(a.earnedAt), "MMM d, yyyy")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Recent rolls */}
      <Card className="border-border bg-card/60 overflow-hidden">
        <div className="p-4 border-b border-border bg-muted/20">
          <h3 className="font-bold uppercase tracking-wider text-sm">Recent Rolls</h3>
        </div>
        {isLoading ? (
          <div className="p-4 space-y-2">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-8 w-full" />)}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/10 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                  <th className="text-left p-3">Time</th>
                  <th className="text-center p-3">Roll</th>
                  <th className="text-left p-3">Result</th>
                  <th className="text-right p-3">Bet</th>
                  <th className="text-right p-3">Payout</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50 font-mono">
                {data?.recentRolls.length === 0 ? (
                  <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No rolls yet.</td></tr>
                ) : data?.recentRolls.map((r) => (
                  <tr key={r.id} className={cn("hover:bg-muted/10 transition-colors", r.resultType === "jackpot" ? "bg-yellow-950/10" : "")}>
                    <td className="p-3 text-muted-foreground text-xs">{format(new Date(r.createdAt), "MMM d, HH:mm")}</td>
                    <td className="p-3 text-center font-bold">{r.rollNumber}</td>
                    <td className={cn("p-3 font-bold uppercase text-xs", resultColor(r.resultType))}>
                      {r.resultType.replace("_", " ")}
                    </td>
                    <td className="p-3 text-right text-muted-foreground">{fmt(r.betAmount)}</td>
                    <td className={cn("p-3 text-right font-bold", r.payout > 0 ? "text-green-400" : "text-destructive")}>
                      {r.payout > 0 ? fmt(r.payout) : `-${fmt(r.betAmount)}`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

import { useGetMyHistory, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

function fmt(n: number) {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

const resultColor = (type: string) => {
  switch (type) {
    case "lose": return "text-destructive";
    case "small_win": return "text-green-400";
    case "big_win": return "text-secondary";
    case "jackpot": return "text-yellow-400";
    default: return "text-muted-foreground";
  }
};

export function History() {
  const { data, isLoading } = useGetMyHistory({ limit: 100 });
  const { data: player } = useGetMe({ query: { enabled: true, queryKey: getGetMeQueryKey() } });

  // Build balance-over-time chart data (oldest first)
  const chartData = (() => {
    if (!data?.rolls || !player) return [];
    // Start from current balance and walk backwards
    const rolls = [...data.rolls].reverse(); // oldest first
    let balance = player.balance;
    // Reconstruct backwards: current balance minus all net changes = starting balance
    const totalNet = rolls.reduce((sum, r) => sum + (r.payout - r.betAmount), 0);
    let running = player.balance - totalNet;
    return rolls.map((r) => {
      const net = r.payout - r.betAmount;
      running += net;
      return {
        time: format(new Date(r.createdAt), "MM/dd HH:mm"),
        balance: running,
        result: r.resultType,
      };
    });
  })();

  return (
    <div className="space-y-6 max-w-3xl mx-auto animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black uppercase tracking-widest">Roll History</h2>
      </div>

      {/* Balance Chart */}
      {(isLoading || (chartData.length > 1)) && (
        <Card className="border-border bg-card/60 p-4">
          <div className="text-xs font-mono uppercase tracking-wider text-muted-foreground mb-4">Balance Over Time</div>
          {isLoading ? <Skeleton className="h-40 w-full" /> : (
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={chartData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="balGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tickFormatter={(v) => fmt(v)} tick={{ fontSize: 9, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={false} width={52} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 11 }}
                  labelStyle={{ color: "hsl(var(--muted-foreground))" }}
                  formatter={(v: number) => [fmt(v), "Balance"]}
                />
                <Area type="monotone" dataKey="balance" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#balGrad)" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </Card>
      )}

      <Card className="border-border bg-card/60 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs uppercase bg-muted/30 text-muted-foreground border-b border-border">
              <tr>
                <th className="px-4 py-3 font-bold tracking-wider">Time</th>
                <th className="px-4 py-3 font-bold tracking-wider text-center">Roll</th>
                <th className="px-4 py-3 font-bold tracking-wider">Result</th>
                <th className="px-4 py-3 font-bold tracking-wider text-right">Bet</th>
                <th className="px-4 py-3 font-bold tracking-wider text-right">Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50 font-mono">
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 5 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                    ))}
                  </tr>
                ))
              ) : data?.rolls.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-12 text-center text-muted-foreground">
                    No history found. Time to roll.
                  </td>
                </tr>
              ) : (
                data?.rolls.map((roll) => {
                  const net = roll.payout - roll.betAmount;
                  return (
                    <tr key={roll.id} className={cn("hover:bg-muted/10 transition-colors", roll.resultType === "jackpot" ? "bg-yellow-950/10" : "")}>
                      <td className="px-4 py-2.5 text-muted-foreground text-xs">
                        {format(new Date(roll.createdAt), "MMM d, HH:mm:ss")}
                      </td>
                      <td className="px-4 py-2.5 text-center font-bold text-foreground">{roll.rollNumber}</td>
                      <td className={cn("px-4 py-2.5 font-bold uppercase text-xs", resultColor(roll.resultType))}>
                        {roll.resultType.replace("_", " ")}
                      </td>
                      <td className="px-4 py-2.5 text-right text-muted-foreground">{fmt(roll.betAmount)}</td>
                      <td className={cn("px-4 py-2.5 text-right font-bold", net >= 0 ? "text-green-400" : "text-destructive")}>
                        {net >= 0 ? `+${fmt(net)}` : `-${fmt(Math.abs(net))}`}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

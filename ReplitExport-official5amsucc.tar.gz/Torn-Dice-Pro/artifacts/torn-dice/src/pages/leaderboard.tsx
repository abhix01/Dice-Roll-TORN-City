import { useGetLeaderboard, useGetGameStats } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Activity, Target, Zap } from "lucide-react";

export function Leaderboard() {
  const { data: leaderboard, isLoading: isLoadingBoard } = useGetLeaderboard();
  const { data: stats, isLoading: isLoadingStats } = useGetGameStats();

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Global Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Rolls", value: stats?.totalRolls.toLocaleString(), icon: Activity, color: "text-primary" },
          { label: "Players", value: stats?.totalPlayers.toLocaleString(), icon: Target, color: "text-blue-400" },
          { label: "Total Paid", value: stats ? `$${(stats.totalPaidOut / 1000000).toFixed(1)}M` : null, icon: Trophy, color: "text-green-400" },
          { label: "Jackpots Hit", value: stats?.totalJackpots.toLocaleString(), icon: Zap, color: "text-yellow-400" },
        ].map((stat, i) => (
          <Card key={i} className="p-4 border-border bg-card/40 backdrop-blur-sm flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
              <span className="text-xs font-bold uppercase tracking-wider">{stat.label}</span>
            </div>
            {isLoadingStats ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <span className="text-2xl font-mono font-black">{stat.value || 0}</span>
            )}
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Most Won */}
        <Card className="border-border bg-card/60 overflow-hidden">
          <div className="p-4 border-b border-border bg-green-500/10">
            <h3 className="font-bold uppercase tracking-wider text-sm flex items-center gap-2 text-green-400">
              <Trophy className="w-4 h-4" />
              Highest Earners
            </h3>
          </div>
          <div className="divide-y divide-border">
            {isLoadingBoard ? (
              Array.from({length: 5}).map((_, i) => <div key={i} className="p-4"><Skeleton className="h-6 w-full" /></div>)
            ) : leaderboard?.mostWon.map((entry, i) => (
              <div key={entry.playerId} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-center gap-4">
                  <span className="text-muted-foreground font-mono text-sm w-4">{i + 1}.</span>
                  <div>
                    <div className="font-bold text-foreground">{entry.name}</div>
                    <div className="text-xs text-muted-foreground">{entry.faction || "No Faction"}</div>
                  </div>
                </div>
                <div className="font-mono text-green-400 font-bold">
                  ${entry.totalWon.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Most Rolls */}
        <Card className="border-border bg-card/60 overflow-hidden">
          <div className="p-4 border-b border-border bg-primary/10">
            <h3 className="font-bold uppercase tracking-wider text-sm flex items-center gap-2 text-primary">
              <Activity className="w-4 h-4" />
              Most Addicted
            </h3>
          </div>
          <div className="divide-y divide-border">
            {isLoadingBoard ? (
              Array.from({length: 5}).map((_, i) => <div key={i} className="p-4"><Skeleton className="h-6 w-full" /></div>)
            ) : leaderboard?.mostRolls.map((entry, i) => (
              <div key={entry.playerId} className="flex items-center justify-between p-4 hover:bg-muted/20 transition-colors">
                <div className="flex items-center gap-4">
                  <span className="text-muted-foreground font-mono text-sm w-4">{i + 1}.</span>
                  <div>
                    <div className="font-bold text-foreground">{entry.name}</div>
                    <div className="text-xs text-muted-foreground">Lvl {entry.level}</div>
                  </div>
                </div>
                <div className="font-mono text-primary font-bold">
                  {entry.totalRolls.toLocaleString()} rolls
                </div>
              </div>
            ))}
          </div>
        </Card>

      </div>
    </div>
  );
}

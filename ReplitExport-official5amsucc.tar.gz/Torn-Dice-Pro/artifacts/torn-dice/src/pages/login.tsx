import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useLoginPlayer } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Shield, Zap, Trophy, Coins, ChevronDown, Star, Lock, ExternalLink, TrendingUp } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Winner {
  id: number;
  playerName: string;
  betAmount: number;
  payout: number;
  resultType: string;
  rollNumber: number;
}

function formatMoney(n: number) {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

function LiveTicker() {
  const [winners, setWinners] = useState<Winner[]>([]);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
    const fetchWinners = async () => {
      try {
        const res = await fetch(`${BASE}/api/game/recent-winners?limit=20`);
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data.winners) && data.winners.length > 0) {
            setWinners(data.winners);
          }
        }
      } catch {
        // silently ignore
      }
    };
    fetchWinners();
    const id = setInterval(fetchWinners, 15_000);
    return () => clearInterval(id);
  }, []);

  if (winners.length === 0) return null;

  const items = [...winners, ...winners];

  return (
    <div className="w-full bg-primary/10 border-b border-primary/20 overflow-hidden py-2 relative">
      <div className="absolute left-0 top-0 h-full w-16 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 h-full w-16 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />
      <div className="flex items-center gap-3 px-4 mb-0.5">
        <span className="text-[10px] font-mono uppercase tracking-widest text-primary shrink-0 flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          Live Wins
        </span>
      </div>
      <div
        ref={trackRef}
        className="flex gap-6 ticker-track"
        style={{ width: "max-content" }}
      >
        {items.map((w, i) => (
          <div
            key={`${w.id}-${i}`}
            className="flex items-center gap-2 shrink-0 px-3 py-0.5 rounded-full border border-primary/10 bg-primary/5 text-xs font-mono"
          >
            <span className="text-yellow-400">
              {w.resultType === "jackpot" ? "🏆" : w.resultType === "big_win" ? "🔥" : "✅"}
            </span>
            <span className="text-foreground font-bold">{w.playerName}</span>
            <span className="text-muted-foreground">rolled</span>
            <span className="text-primary font-bold">{w.rollNumber}</span>
            <span className="text-muted-foreground">→ won</span>
            <span className="text-green-400 font-bold">{formatMoney(w.payout)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const DICE_FACES = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];

function FloatingDie({ style }: { style: React.CSSProperties }) {
  const [face, setFace] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setFace(Math.floor(Math.random() * 6)), 1200 + Math.random() * 2000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="floating-die select-none pointer-events-none" style={style}>
      {DICE_FACES[face]}
    </span>
  );
}

function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        let start = 0;
        const step = target / 60;
        const id = setInterval(() => {
          start += step;
          if (start >= target) { setVal(target); clearInterval(id); }
          else setVal(Math.floor(start));
        }, 16);
        observer.disconnect();
      }
    });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

const FEATURES = [
  {
    icon: <Zap className="w-6 h-6" />,
    title: "Instant Rolls",
    desc: "Roll the dice in seconds. Results are instant, payouts are immediate. No waiting, no delays.",
    color: "from-cyan-500/20 to-cyan-500/5",
    border: "border-cyan-500/20",
    iconColor: "text-cyan-400",
  },
  {
    icon: <Trophy className="w-6 h-6" />,
    title: "Massive Jackpots",
    desc: "Hit 99–100 with a bet over $100K and claim the entire jackpot pool. Life-changing payouts.",
    color: "from-yellow-500/20 to-yellow-500/5",
    border: "border-yellow-500/20",
    iconColor: "text-yellow-400",
  },
  {
    icon: <Coins className="w-6 h-6" />,
    title: "Big Multipliers",
    desc: "Roll 61–90 for a 1.4× payout. Roll 91–100 for a 3× payout. The odds are in your favor.",
    color: "from-green-500/20 to-green-500/5",
    border: "border-green-500/20",
    iconColor: "text-green-400",
  },
  {
    icon: <Star className="w-6 h-6" />,
    title: "Achievements",
    desc: "Unlock badges as you play — First Win, High Roller, Whale, Veteran and more.",
    color: "from-purple-500/20 to-purple-500/5",
    border: "border-purple-500/20",
    iconColor: "text-purple-400",
  },
];

const STEPS = [
  { step: "01", title: "Get your Public API Key", desc: "Go to Torn → Settings → API Key → Select 'Public Access'. Copy the key." },
  { step: "02", title: "Enter the Den", desc: "Paste your key below and log in. Your Torn identity is verified instantly." },
  { step: "03", title: "Place your bet", desc: "Choose your bet amount and roll the dice. Big wins land directly in your balance." },
];

const TRUST_POINTS = [
  { icon: <Lock className="w-4 h-4" />, text: "We only ask for your Public API key — it cannot access your account, items, or perform any actions." },
  { icon: <Shield className="w-4 h-4" />, text: "Your key is never stored in plain text. It's used only to verify your Torn identity." },
  { icon: <ExternalLink className="w-4 h-4" />, text: "You can revoke your API key from Torn Settings at any time, instantly cutting access." },
];

export function Login() {
  const [apiKey, setApiKey] = useState("");
  const { login, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const loginMutation = useLoginPlayer();
  const formRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isAuthenticated) setLocation("/");
  }, [isAuthenticated, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim()) return;
    loginMutation.mutate(
      { data: { apiKey } },
      { onSuccess: (data) => { login(data.token); setLocation("/"); } }
    );
  };

  const scrollToForm = () => formRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });

  return (
    <div className="min-h-screen w-full overflow-x-hidden -mx-4 sm:-mx-6 lg:-mx-8 -mt-4 sm:-mt-6 lg:-mt-8 w-[calc(100%+2rem)] sm:w-[calc(100%+3rem)] lg:w-[calc(100%+4rem)]">
      <LiveTicker />
      <style>{`
        @keyframes floatY {
          0%, 100% { transform: translateY(0px) rotate(0deg); opacity: 0.18; }
          50% { transform: translateY(-24px) rotate(10deg); opacity: 0.32; }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(32px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
        @keyframes glow-pulse {
          0%, 100% { box-shadow: 0 0 20px rgba(0,255,255,0.15); }
          50% { box-shadow: 0 0 40px rgba(0,255,255,0.35), 0 0 80px rgba(0,255,255,0.1); }
        }
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(8px); }
        }
        @keyframes ticker-scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .ticker-track {
          animation: ticker-scroll 40s linear infinite;
        }
        .ticker-track:hover {
          animation-play-state: paused;
        }
        .floating-die {
          position: absolute;
          font-size: clamp(2rem, 5vw, 4rem);
          animation: floatY var(--dur, 4s) ease-in-out infinite;
          animation-delay: var(--delay, 0s);
        }
        .fade-up { animation: fadeUp 0.7s ease both; }
        .fade-up-1 { animation: fadeUp 0.7s 0.1s ease both; }
        .fade-up-2 { animation: fadeUp 0.7s 0.2s ease both; }
        .fade-up-3 { animation: fadeUp 0.7s 0.3s ease both; }
        .shimmer-text {
          background: linear-gradient(90deg, #00ffff, #ff00ff, #00ffff);
          background-size: 200% auto;
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: shimmer 4s linear infinite;
        }
        .glow-card { animation: glow-pulse 3s ease-in-out infinite; }
        .bounce-arrow { animation: bounce-slow 2s ease-in-out infinite; }
      `}</style>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-4 py-20 overflow-hidden">
        {/* Background glow blobs */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-cyan-500/5 blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-fuchsia-500/5 blur-3xl" />
        </div>

        {/* Floating dice */}
        <FloatingDie style={{ top: "12%", left: "8%", "--dur": "5s", "--delay": "0s" } as React.CSSProperties} />
        <FloatingDie style={{ top: "20%", right: "10%", "--dur": "6s", "--delay": "1s" } as React.CSSProperties} />
        <FloatingDie style={{ bottom: "25%", left: "14%", "--dur": "4.5s", "--delay": "0.5s" } as React.CSSProperties} />
        <FloatingDie style={{ bottom: "18%", right: "8%", "--dur": "7s", "--delay": "2s" } as React.CSSProperties} />
        <FloatingDie style={{ top: "50%", left: "3%", "--dur": "5.5s", "--delay": "1.5s" } as React.CSSProperties} />
        <FloatingDie style={{ top: "45%", right: "4%", "--dur": "6.5s", "--delay": "0.8s" } as React.CSSProperties} />

        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          {/* Badge */}
          <div className="fade-up inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-500/30 bg-cyan-500/10 text-cyan-400 text-xs font-mono uppercase tracking-widest">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            Torn City Official Dice Game
          </div>

          {/* Title */}
          <div className="fade-up-1 space-y-3">
            <h1 className="text-6xl sm:text-7xl font-black uppercase tracking-tighter">
              <span className="shimmer-text">Torn</span>
              <br />
              <span className="text-foreground">Dice Roll</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-xl mx-auto font-mono">
              The high-stakes back-room dice game for Torn City players.<br className="hidden sm:block" />
              Roll. Win. Collect. Repeat.
            </p>
          </div>

          {/* Stats row */}
          <div className="fade-up-2 flex flex-wrap justify-center gap-8 py-4">
            {[
              { label: "Max Multiplier", value: <span>3<span className="text-cyan-400">×</span></span> },
              { label: "Jackpot Eligible", value: <span><span className="text-yellow-400">$100K</span>+ bets</span> },
              { label: "Win Chance", value: <span><span className="text-green-400">40</span>%</span> },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-2xl font-black">{s.value}</div>
                <div className="text-xs text-muted-foreground font-mono uppercase tracking-widest mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="fade-up-3 flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              onClick={scrollToForm}
              size="lg"
              className="h-14 px-10 text-lg font-black uppercase tracking-widest bg-primary text-primary-foreground hover:bg-primary/90 glow-card"
            >
              🎲 Enter the Den
            </Button>
            <Button
              onClick={scrollToForm}
              size="lg"
              variant="outline"
              className="h-14 px-8 text-lg font-bold border-border hover:border-primary/40 hover:bg-primary/5"
            >
              How it works
            </Button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bounce-arrow text-muted-foreground">
          <ChevronDown className="w-6 h-6" />
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-24 px-4 max-w-4xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-2">Simple as it gets</p>
          <h2 className="text-4xl font-black uppercase tracking-tight">How It Works</h2>
        </div>
        <div className="grid sm:grid-cols-3 gap-6">
          {STEPS.map((s) => (
            <div key={s.step} className="relative p-6 rounded-xl border border-border bg-card/50 backdrop-blur-sm group hover:border-primary/30 transition-colors">
              <div className="text-5xl font-black text-primary/10 group-hover:text-primary/20 transition-colors absolute top-4 right-5 font-mono">{s.step}</div>
              <div className="text-3xl font-black text-primary/30 font-mono mb-3">{s.step}</div>
              <h3 className="font-bold text-lg mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── PAYOUT TABLE ── */}
      <section className="py-20 px-4 bg-card/30 border-y border-border">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-2">Transparent odds</p>
            <h2 className="text-4xl font-black uppercase tracking-tight">Payout Structure</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { range: "1 – 60", label: "Loss", multiplier: "0×", color: "border-red-500/30 bg-red-500/5", badge: "bg-red-500/20 text-red-400", emoji: "💀" },
              { range: "61 – 90", label: "Small Win", multiplier: "1.4×", color: "border-green-500/30 bg-green-500/5", badge: "bg-green-500/20 text-green-400", emoji: "✅" },
              { range: "91 – 100", label: "Big Win", multiplier: "3×", color: "border-cyan-500/30 bg-cyan-500/5", badge: "bg-cyan-500/20 text-cyan-400", emoji: "🔥" },
            ].map((row) => (
              <div key={row.range} className={`rounded-xl border p-6 text-center ${row.color}`}>
                <div className="text-4xl mb-3">{row.emoji}</div>
                <div className="font-mono text-2xl font-black mb-1">{row.multiplier}</div>
                <div className="font-bold mb-1">{row.label}</div>
                <div className={`inline-block text-xs font-mono px-2 py-0.5 rounded-full ${row.badge}`}>{row.range}</div>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-muted-foreground mt-6 font-mono">
            🏆 Roll <span className="text-yellow-400 font-bold">99–100</span> with a bet over <span className="text-yellow-400 font-bold">$100,000</span> to claim the entire jackpot pool.
          </p>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section className="py-24 px-4 max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-2">Everything you need</p>
          <h2 className="text-4xl font-black uppercase tracking-tight">What You Get</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map((f) => (
            <div key={f.title} className={`rounded-xl border ${f.border} bg-gradient-to-b ${f.color} p-6 hover:scale-[1.02] transition-transform`}>
              <div className={`${f.iconColor} mb-4`}>{f.icon}</div>
              <h3 className="font-bold text-base mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── TRUST SECTION ── */}
      <section className="py-20 px-4 bg-card/30 border-y border-border">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-green-500/30 bg-green-500/10 text-green-400 text-xs font-mono uppercase tracking-widest mb-6">
            <Shield className="w-3.5 h-3.5" />
            Your Security Matters
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tight mb-4">Why It's Safe to Use Your API Key</h2>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            We understand why handing over an API key feels uncomfortable. Here's exactly why it's safe:
          </p>
          <div className="space-y-4 text-left">
            {TRUST_POINTS.map((t, i) => (
              <div key={i} className="flex gap-4 p-4 rounded-xl border border-green-500/20 bg-green-500/5">
                <div className="text-green-400 mt-0.5 shrink-0">{t.icon}</div>
                <p className="text-sm text-muted-foreground leading-relaxed">{t.text}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-xs text-muted-foreground font-mono">
            Torn Public API key only grants read access to basic public profile info (name, level, ID). Nothing else.
          </p>
        </div>
      </section>

      {/* ── LOGIN FORM ── */}
      <section ref={formRef} className="py-24 px-4 flex justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <p className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-2">Ready to play?</p>
            <h2 className="text-3xl font-black uppercase tracking-tight">Enter the Den</h2>
            <p className="text-muted-foreground mt-2 text-sm">Paste your Torn Public API key to get started.</p>
          </div>

          <div className="rounded-2xl border border-primary/20 bg-card/80 backdrop-blur-xl p-8 shadow-[0_0_60px_-12px_rgba(0,255,255,0.15)]">
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

            <form onSubmit={handleSubmit} className="space-y-5">
              {loginMutation.isError && (
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/20">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    {loginMutation.error?.data?.error || "Failed to login. Check your API key."}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <label htmlFor="apiKey" className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-green-400" />
                  Torn Public API Key
                </label>
                <Input
                  id="apiKey"
                  type="password"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Paste your Public API key here"
                  className="font-mono bg-background/50 border-border focus-visible:ring-primary h-12 text-base"
                />
                <p className="text-[11px] text-muted-foreground font-mono flex items-start gap-1">
                  <Shield className="w-3 h-3 text-green-400 mt-0.5 shrink-0" />
                  Torn → Settings → API Key → Public Access. Read-only. Cannot perform any actions on your account.
                </p>
              </div>

              <Button
                type="submit"
                className="w-full h-12 text-base font-black tracking-widest uppercase bg-primary text-primary-foreground hover:bg-primary/90 transition-all glow-card"
                disabled={loginMutation.isPending || !apiKey.trim()}
              >
                {loginMutation.isPending ? "Connecting..." : "🎲 Roll the Dice"}
              </Button>
            </form>

            <div className="mt-6 pt-5 border-t border-border space-y-2">
              <p className="text-xs text-center text-muted-foreground font-mono">How to find your API key:</p>
              <ol className="text-xs text-muted-foreground space-y-1 font-mono list-decimal list-inside">
                <li>Log in to <span className="text-primary">torn.com</span></li>
                <li>Go to <span className="text-primary">Settings → API Key</span></li>
                <li>Set access level to <span className="text-primary">Public</span></li>
                <li>Copy and paste it above</li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 text-center">
        <p className="text-xs text-muted-foreground font-mono">
          Torn Dice Roll — Unofficial fan-made game for Torn City players. Not affiliated with Torn Ltd.
        </p>
      </footer>
    </div>
  );
}

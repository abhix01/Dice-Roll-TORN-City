import { useState, useRef, useCallback, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useRollDice,
  useGetRecentWinners,
  useGetMe,
  useGetJackpot,
  useGetDailyBonus,
  useClaimDailyBonus,
  getGetRecentWinnersQueryKey,
  getGetMeQueryKey,
  getGetMyHistoryQueryKey,
  getGetJackpotQueryKey,
  getGetDailyBonusQueryKey,
} from "@workspace/api-client-react";
import type { RollResult, Achievement } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Coins, Sparkles, Play, Square, RefreshCw, Trophy, Gift, Star } from "lucide-react";
import { cn } from "@/lib/utils";

const MIN_BET = 10_000;
const DEFAULT_BET = 1_000_000;

const ROLL_COUNTS = [5, 10, 25, 50, 100];
const DELAYS = [
  { label: "Turbo", ms: 250 },
  { label: "Fast", ms: 600 },
  { label: "Normal", ms: 1100 },
];

function formatMoney(n: number) {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(2)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

function formatPnl(n: number) {
  const abs = formatMoney(Math.abs(n));
  return n >= 0 ? `+${abs}` : `-${abs.slice(1)}`;
}

function useCountdown(targetIso: string | null | undefined) {
  const [remaining, setRemaining] = useState("");
  useEffect(() => {
    if (!targetIso) { setRemaining(""); return; }
    const tick = () => {
      const diff = new Date(targetIso).getTime() - Date.now();
      if (diff <= 0) { setRemaining(""); return; }
      const h = Math.floor(diff / 3_600_000);
      const m = Math.floor((diff % 3_600_000) / 60_000);
      const s = Math.floor((diff % 60_000) / 1_000);
      setRemaining(`${h}h ${m.toString().padStart(2, "0")}m ${s.toString().padStart(2, "0")}s`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [targetIso]);
  return remaining;
}

export function Home() {
  const queryClient = useQueryClient();
  const rollMutation = useRollDice();
  const claimBonus = useClaimDailyBonus();
  const { data: winnersData } = useGetRecentWinners({ limit: 5 });
  const { data: player } = useGetMe({ query: { enabled: true, queryKey: getGetMeQueryKey() } });
  const { data: jackpotData } = useGetJackpot({
    query: {
      queryKey: getGetJackpotQueryKey(),
      refetchInterval: 5000,
    },
  });
  const { data: bonusData, refetch: refetchBonus } = useGetDailyBonus({
    query: { queryKey: getGetDailyBonusQueryKey(), refetchInterval: 60_000 },
  });

  const countdown = useCountdown(bonusData?.nextClaimAt);

  const jackpotPool = jackpotData?.pool ?? 0;
  const maxBet = player?.balance ?? DEFAULT_BET;
  const [betAmount, setBetAmount] = useState(DEFAULT_BET);
  const [mode, setMode] = useState<"manual" | "auto">("manual");

  // Manual roll state
  const [rolling, setRolling] = useState(false);
  const [displayNumber, setDisplayNumber] = useState<number | null>(null);
  const [lastResult, setLastResult] = useState<RollResult | null>(null);
  const [jackpotWon, setJackpotWon] = useState<number | null>(null);
  const animIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Achievement toast state
  const [achievementToasts, setAchievementToasts] = useState<Achievement[]>([]);

  const showAchievements = (achievements: Achievement[]) => {
    if (!achievements || achievements.length === 0) return;
    setAchievementToasts((prev) => [...prev, ...achievements]);
    achievements.forEach((_, i) => {
      setTimeout(() => {
        setAchievementToasts((prev) => prev.slice(1));
      }, 4000 + i * 500);
    });
  };

  // Auto roll state
  const [autoRolls, setAutoRolls] = useState(10);
  const [autoDelay, setAutoDelay] = useState(600);
  const [stopOnJackpot, setStopOnJackpot] = useState(true);
  const [stopBelowBalance, setStopBelowBalance] = useState(0);
  const [autoRunning, setAutoRunning] = useState(false);
  const [autoProgress, setAutoProgress] = useState({ done: 0, total: 0 });
  const [autoNetPnl, setAutoNetPnl] = useState(0);
  const [autoStopReason, setAutoStopReason] = useState<string | null>(null);
  const autoStopRef = useRef(false);

  const clampedBet = Math.max(MIN_BET, Math.min(betAmount, maxBet));

  const JACKPOT_MIN_BET = 100_000;

  // Stores the pending result so settleAnim can use it
  const pendingResultRef = useRef<RollResult | null>(null);

  const startAnim = (fast = false) => {
    if (animIntervalRef.current) clearInterval(animIntervalRef.current);
    pendingResultRef.current = null;
    const ticks = fast ? 8 : 20;
    const ms = fast ? 30 : 50;
    let count = 0;
    animIntervalRef.current = setInterval(() => {
      // If result arrived, begin deceleration settle
      if (pendingResultRef.current) {
        clearInterval(animIntervalRef.current!);
        animIntervalRef.current = null;
        settleAnim(pendingResultRef.current);
        return;
      }
      // Never flash 99/100 during animation — prevents false jackpot impressions
      setDisplayNumber(Math.floor(Math.random() * 97) + 1);
      count++;
      // Minimum spin of (ticks) before we'll accept the result
      if (count >= ticks && pendingResultRef.current) {
        clearInterval(animIntervalRef.current!);
        animIntervalRef.current = null;
        settleAnim(pendingResultRef.current);
      }
    }, ms);
  };

  // Decelerate and land on the real roll number, then reveal result
  const settleAnim = (data: RollResult) => {
    const delays = [60, 90, 130, 180, 240, 300]; // slowing down
    let i = 0;
    const step = () => {
      if (i < delays.length - 1) {
        setDisplayNumber(Math.floor(Math.random() * 97) + 1);
        i++;
        setTimeout(step, delays[i]);
      } else {
        // Land exactly on the real server number
        setDisplayNumber(data.rollNumber);
        setLastResult(data);
        if (data.resultType === "jackpot") setJackpotWon(data.payout);
        setRolling(false);
        invalidateAll();
        if (data.newAchievements && data.newAchievements.length > 0) {
          showAchievements(data.newAchievements);
        }
      }
    };
    step();
  };

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetRecentWinnersQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetMyHistoryQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetJackpotQueryKey() });
  };

  const handleClaimBonus = () => {
    claimBonus.mutate(undefined, {
      onSuccess: () => {
        refetchBonus();
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      },
    });
  };

  const handleManualRoll = () => {
    if (rolling || clampedBet > (player?.balance ?? 0)) return;
    setRolling(true);
    setLastResult(null);
    setJackpotWon(null);
    startAnim();
    rollMutation.mutate(
      { data: { betAmount: clampedBet } },
      {
        onSuccess: (data) => {
          // Store result — the spinning animation will pick it up and
          // decelerate to land exactly on the real roll number
          pendingResultRef.current = data;
          // If animation already finished its minimum ticks, settle now
          if (!animIntervalRef.current) {
            settleAnim(data);
          }
        },
        onError: () => {
          pendingResultRef.current = null;
          if (animIntervalRef.current) {
            clearInterval(animIntervalRef.current);
            animIntervalRef.current = null;
          }
          setRolling(false);
        },
      }
    );
  };

  const sleep = (ms: number) => new Promise<void>((res) => setTimeout(res, ms));

  const runAutoRoll = useCallback(async () => {
    autoStopRef.current = false;
    setAutoRunning(true);
    setAutoNetPnl(0);
    setAutoStopReason(null);
    setLastResult(null);
    setJackpotWon(null);

    let pnl = 0;
    let currentBalance = player?.balance ?? 0;

    for (let i = 0; i < autoRolls; i++) {
      if (autoStopRef.current) { setAutoStopReason("Stopped by you"); break; }
      if (currentBalance < clampedBet) { setAutoStopReason("Insufficient balance"); break; }
      if (stopBelowBalance > 0 && currentBalance <= stopBelowBalance) {
        setAutoStopReason(`Balance fell below ${formatMoney(stopBelowBalance)}`);
        break;
      }

      setAutoProgress({ done: i, total: autoRolls });
      startAnim(true);

      let result: RollResult | null = null;
      try {
        result = await rollMutation.mutateAsync({ data: { betAmount: clampedBet } });
      } catch {
        setAutoStopReason("Roll failed");
        break;
      }

      const net = result.payout - result.betAmount;
      pnl += net;
      currentBalance += net;

      setDisplayNumber(result.rollNumber);
      setLastResult(result);
      if (result.resultType === "jackpot") setJackpotWon(result.payout);
      setAutoNetPnl(pnl);
      setAutoProgress({ done: i + 1, total: autoRolls });
      invalidateAll();

      if (result.newAchievements && result.newAchievements.length > 0) {
        showAchievements(result.newAchievements);
      }

      if (stopOnJackpot && result.resultType === "jackpot") {
        setAutoStopReason("Jackpot hit!");
        break;
      }

      if (i < autoRolls - 1 && !autoStopRef.current) await sleep(autoDelay);
    }

    setAutoRunning(false);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRolls, autoDelay, clampedBet, stopOnJackpot, stopBelowBalance, player?.balance, rollMutation]);

  const stopAutoRoll = () => { autoStopRef.current = true; };

  const getResultStyle = (type?: string) => {
    switch (type) {
      case "lose": return "text-destructive border-destructive/50";
      case "small_win": return "text-green-400 border-green-400/50";
      case "big_win": return "text-secondary border-secondary/50 animate-pulse";
      case "jackpot": return "text-yellow-400 border-yellow-400 animate-pulse";
      default: return "text-primary border-primary/50";
    }
  };

  const insufficientBalance = clampedBet > (player?.balance ?? 0) || (player?.balance ?? 0) < MIN_BET;

  return (
    <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

      {/* Achievement toasts */}
      {achievementToasts.length > 0 && (
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none">
          {achievementToasts.map((a, i) => (
            <div key={`${a.id}-${i}`}
              className="flex items-center gap-3 px-4 py-3 rounded-xl border border-yellow-500/40 bg-yellow-950/90 backdrop-blur-xl shadow-2xl animate-in slide-in-from-bottom-4 text-yellow-200"
            >
              <span className="text-2xl">{a.emoji}</span>
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-yellow-500">Achievement unlocked!</div>
                <div className="font-bold text-sm">{a.name}</div>
                <div className="text-xs text-yellow-300/70">{a.description}</div>
              </div>
              <Star className="w-4 h-4 text-yellow-400 shrink-0" />
            </div>
          ))}
        </div>
      )}

      {/* Left: Game Area */}
      <div className="lg:col-span-8 space-y-4">

        {/* Progressive Jackpot Banner */}
        <div className={cn(
          "relative overflow-hidden rounded-xl border px-6 py-4 flex items-center justify-between gap-4",
          "border-yellow-500/40 bg-gradient-to-r from-yellow-950/60 via-amber-900/30 to-yellow-950/60",
          "shadow-[0_0_40px_-10px_rgba(234,179,8,0.3)]"
        )}>
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.04]" />
          <div className="flex items-center gap-3 relative z-10">
            <Trophy className="w-6 h-6 text-yellow-400 shrink-0" />
            <div>
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-yellow-600">Progressive Jackpot</div>
              <div className="text-xs text-yellow-700/70 font-mono">5% of every loss feeds the pool · Roll 99–100 to win it all</div>
            </div>
          </div>
          <div className="relative z-10 text-right shrink-0">
            <div className={cn(
              "text-2xl sm:text-3xl font-black font-mono tabular-nums text-yellow-300",
              "drop-shadow-[0_0_12px_rgba(253,224,71,0.6)]"
            )}>
              {formatMoney(jackpotPool)}
            </div>
            {jackpotWon !== null && (
              <div className="text-xs font-mono text-yellow-400 animate-pulse">YOU WON THIS!</div>
            )}
          </div>
        </div>

        {/* Daily Bonus Banner */}
        {bonusData && (
          <div className={cn(
            "relative overflow-hidden rounded-xl border px-5 py-3 flex items-center justify-between gap-4",
            bonusData.canClaim
              ? "border-emerald-500/40 bg-gradient-to-r from-emerald-950/60 via-green-900/30 to-emerald-950/60 shadow-[0_0_30px_-10px_rgba(52,211,153,0.3)]"
              : "border-muted/40 bg-muted/20"
          )}>
            <div className="flex items-center gap-3">
              <Gift className={cn("w-5 h-5 shrink-0", bonusData.canClaim ? "text-emerald-400" : "text-muted-foreground")} />
              <div>
                <div className={cn("text-[10px] font-mono uppercase tracking-[0.2em]", bonusData.canClaim ? "text-emerald-500" : "text-muted-foreground")}>
                  Daily Bonus
                </div>
                <div className={cn("text-xs font-mono", bonusData.canClaim ? "text-emerald-300/70" : "text-muted-foreground/60")}>
                  {bonusData.canClaim
                    ? "Claim your free $100,000 today!"
                    : `Next bonus in ${countdown || "…"}`}
                </div>
              </div>
            </div>
            <Button
              size="sm"
              variant={bonusData.canClaim ? "default" : "ghost"}
              disabled={!bonusData.canClaim || claimBonus.isPending}
              onClick={handleClaimBonus}
              className={cn(
                "shrink-0 font-mono text-xs",
                bonusData.canClaim && "bg-emerald-600 hover:bg-emerald-500 text-white"
              )}
            >
              {claimBonus.isPending ? "Claiming…" : bonusData.canClaim ? "Claim $100K" : "Claimed"}
            </Button>
          </div>
        )}

        {/* Mode Tabs */}
        <Tabs value={mode} onValueChange={(v) => !autoRunning && setMode(v as "manual" | "auto")}>
          <TabsList className="w-full bg-muted/40">
            <TabsTrigger value="manual" className="flex-1" disabled={autoRunning}>Manual</TabsTrigger>
            <TabsTrigger value="auto" className="flex-1" disabled={autoRunning}>
              <RefreshCw className="w-3 h-3 mr-1.5" />
              Auto Roll
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <Card className="border-border bg-card/40 backdrop-blur-sm relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent opacity-50" />
          <CardContent className="p-6 sm:p-8 flex flex-col items-center justify-center min-h-[320px] relative z-10 gap-5">

            {/* Number Display */}
            <div className={cn(
              "w-36 h-36 sm:w-48 sm:h-48 rounded-full border-4 flex items-center justify-center bg-background/80 shadow-2xl transition-all duration-300",
              getResultStyle(lastResult?.resultType)
            )}>
              <span className={cn(
                "text-5xl sm:text-6xl font-black font-mono tabular-nums tracking-tighter",
                (rolling || autoRunning) ? "animate-pulse text-muted-foreground blur-[1px]" : ""
              )}>
                {displayNumber ?? "--"}
              </span>
            </div>

            {/* Auto progress bar */}
            {mode === "auto" && (autoRunning || autoProgress.done > 0) && (
              <div className="w-full max-w-sm space-y-1.5">
                <div className="flex justify-between text-xs font-mono text-muted-foreground">
                  <span>Roll {autoProgress.done} / {autoProgress.total}</span>
                  <span className={cn("font-bold", autoNetPnl >= 0 ? "text-green-400" : "text-destructive")}>
                    {formatPnl(autoNetPnl)}
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-300",
                      lastResult?.resultType === "jackpot" ? "bg-yellow-400" : autoNetPnl >= 0 ? "bg-green-500" : "bg-destructive"
                    )}
                    style={{ width: `${autoProgress.total ? (autoProgress.done / autoProgress.total) * 100 : 0}%` }}
                  />
                </div>
                {autoStopReason && !autoRunning && (
                  <p className={cn("text-xs font-mono text-center pt-0.5", autoStopReason === "Jackpot hit!" ? "text-yellow-400" : "text-muted-foreground")}>
                    {autoStopReason}
                  </p>
                )}
              </div>
            )}

            {/* Bet Sizing */}
            <div className="w-full max-w-sm space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-muted-foreground">
                <span className="uppercase tracking-wider">Bet Amount</span>
                <div className="flex items-center gap-2">
                  <span className="text-foreground font-bold text-sm">{formatMoney(clampedBet)}</span>
                  {player && <span className="text-muted-foreground">/ {formatMoney(player.balance)}</span>}
                </div>
              </div>
              <Slider
                min={MIN_BET}
                max={Math.max(maxBet, MIN_BET)}
                step={10_000}
                value={[clampedBet]}
                onValueChange={([v]) => setBetAmount(v)}
                disabled={rolling || autoRunning}
              />
              <div className="grid grid-cols-7 gap-1">
                {[10_000, 50_000, 100_000, 500_000, 1_000_000, 5_000_000, 10_000_000].map((p) => {
                  const eligible = p > JACKPOT_MIN_BET;
                  return (
                    <button
                      key={p}
                      onClick={() => setBetAmount(Math.min(p, maxBet))}
                      disabled={rolling || autoRunning || p > maxBet}
                      className={cn(
                        "py-1 text-[10px] font-mono rounded border transition-colors leading-tight flex flex-col items-center",
                        clampedBet === p ? "border-primary bg-primary/10 text-primary" : "",
                        p <= maxBet && !rolling && !autoRunning
                          ? "border-border text-muted-foreground hover:border-primary/50 hover:text-primary"
                          : "border-border/30 text-muted-foreground/30 cursor-not-allowed"
                      )}
                    >
                      <span>{formatMoney(p)}</span>
                      {eligible && <span className="text-[8px] text-yellow-500/70">⚡ jackpot</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ── MANUAL MODE ── */}
            {mode === "manual" && (
              <>
                <Button
                  size="lg"
                  onClick={handleManualRoll}
                  disabled={rolling || rollMutation.isPending || insufficientBalance}
                  className={cn(
                    "w-full max-w-sm h-14 text-xl font-black tracking-[0.2em] uppercase rounded-xl transition-all duration-150 active:scale-95",
                    insufficientBalance || rolling
                      ? "bg-muted text-muted-foreground cursor-not-allowed"
                      : "bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_30px_-5px_hsl(var(--primary))]"
                  )}
                >
                  {insufficientBalance && !rolling ? "Insufficient Balance" : rolling ? "Rolling..." : `Roll ${formatMoney(clampedBet)}`}
                </Button>
                <div className="h-12 flex items-center justify-center">
                  {lastResult && (
                    <div className="text-center animate-in fade-in slide-in-from-bottom-4">
                      {lastResult.resultType === "jackpot" ? (
                        <div>
                          <div className="text-2xl font-black uppercase tracking-widest text-yellow-400 drop-shadow-[0_0_10px_rgba(253,224,71,0.8)]">
                            JACKPOT!
                          </div>
                          <div className="text-sm font-mono text-yellow-300">{formatMoney(lastResult.payout)} won!</div>
                        </div>
                      ) : (
                        <div>
                          <div className={cn("text-2xl font-bold uppercase tracking-widest", getResultStyle(lastResult.resultType).split(" ")[0])}>
                            {lastResult.resultType.replace("_", " ")}
                          </div>
                          <div className={cn("text-sm font-mono", lastResult.resultType === "lose" ? "text-destructive" : "text-green-400")}>
                            {lastResult.resultType === "lose"
                              ? `-${formatMoney(lastResult.betAmount)}`
                              : formatPnl(lastResult.payout - lastResult.betAmount)}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </>
            )}

            {/* ── AUTO MODE ── */}
            {mode === "auto" && (
              <div className="w-full max-w-sm space-y-4">
                <div className="space-y-2">
                  <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Number of Rolls</div>
                  <div className="flex gap-2">
                    {ROLL_COUNTS.map((n) => (
                      <button key={n} onClick={() => setAutoRolls(n)} disabled={autoRunning}
                        className={cn("flex-1 py-1.5 text-xs font-mono rounded border transition-colors",
                          autoRolls === n ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/40 hover:text-primary"
                        )}>
                        {n}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Speed</div>
                  <div className="flex gap-2">
                    {DELAYS.map((d) => (
                      <button key={d.ms} onClick={() => setAutoDelay(d.ms)} disabled={autoRunning}
                        className={cn("flex-1 py-1.5 text-xs font-mono rounded border transition-colors",
                          autoDelay === d.ms ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/40 hover:text-primary"
                        )}>
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Stop Conditions</div>
                  <label className="flex items-center gap-2.5 cursor-pointer group">
                    <div onClick={() => !autoRunning && setStopOnJackpot((v) => !v)}
                      className={cn("w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors cursor-pointer",
                        stopOnJackpot ? "bg-yellow-400/20 border-yellow-400" : "border-border"
                      )}>
                      {stopOnJackpot && <div className="w-2 h-2 rounded-sm bg-yellow-400" />}
                    </div>
                    <span className="text-xs font-mono text-muted-foreground group-hover:text-foreground transition-colors">Stop on jackpot</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <div onClick={() => !autoRunning && setStopBelowBalance((v) => (v > 0 ? 0 : 1_000_000))}
                      className={cn("w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors cursor-pointer",
                        stopBelowBalance > 0 ? "bg-destructive/20 border-destructive" : "border-border"
                      )}>
                      {stopBelowBalance > 0 && <div className="w-2 h-2 rounded-sm bg-destructive" />}
                    </div>
                    <span className="text-xs font-mono text-muted-foreground">Stop if balance &lt;</span>
                    <input type="number" value={stopBelowBalance || ""} onChange={(e) => setStopBelowBalance(Math.max(0, parseInt(e.target.value) || 0))}
                      disabled={autoRunning} placeholder="0"
                      className="flex-1 px-2 py-1 text-xs font-mono bg-background/50 border border-border rounded focus:outline-none focus:border-primary/50 text-foreground" />
                  </div>
                </div>

                {autoRunning ? (
                  <Button onClick={stopAutoRoll}
                    className="w-full h-12 text-base font-black uppercase tracking-widest bg-destructive/20 text-destructive border border-destructive/40 hover:bg-destructive/30 rounded-xl">
                    <Square className="w-4 h-4 mr-2 fill-destructive" /> Stop
                  </Button>
                ) : (
                  <Button onClick={runAutoRoll} disabled={insufficientBalance}
                    className={cn("w-full h-12 text-base font-black uppercase tracking-widest rounded-xl transition-all active:scale-95",
                      insufficientBalance ? "bg-muted text-muted-foreground cursor-not-allowed"
                        : "bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_30px_-5px_hsl(var(--primary))]"
                    )}>
                    <Play className="w-4 h-4 mr-2 fill-current" />
                    Roll {autoRolls}× · {formatMoney(clampedBet)} each
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Right: Info */}
      <div className="lg:col-span-4 space-y-6">
        <Card className="border-border bg-card/60">
          <div className="p-4 border-b border-border bg-muted/20">
            <h3 className="font-bold uppercase tracking-wider text-sm flex items-center gap-2">
              <Coins className="w-4 h-4 text-primary" />
              Payouts <span className="text-muted-foreground font-normal text-xs ml-1">for {formatMoney(clampedBet)}</span>
            </h3>
          </div>
          <div className="divide-y divide-border">
            {/* Lose */}
            <div className="flex justify-between items-center p-3 text-sm font-mono">
              <span className="text-muted-foreground w-16">1–60</span>
              <span className="font-bold text-destructive flex-1 text-center">Lose</span>
              <span className="text-destructive font-bold text-right">-{formatMoney(clampedBet)}</span>
            </div>
            {/* Small Win */}
            <div className="flex justify-between items-center p-3 text-sm font-mono">
              <span className="text-muted-foreground w-16">61–90</span>
              <span className="font-bold text-green-400 flex-1 text-center">Small Win</span>
              <span className="text-green-400 font-bold text-right">+{formatMoney(Math.floor(clampedBet * 0.4))}</span>
            </div>
            {/* Big Win */}
            <div className="flex justify-between items-center p-3 text-sm font-mono">
              <span className="text-muted-foreground w-16">91–98</span>
              <span className="font-bold text-secondary flex-1 text-center">Big Win</span>
              <span className="text-secondary font-bold text-right">+{formatMoney(clampedBet * 2)}</span>
            </div>
            {/* Jackpot */}
            <div className="flex justify-between items-center p-3 text-sm font-mono bg-yellow-950/20">
              <span className="text-muted-foreground w-16">99–100</span>
              <span className="font-bold text-yellow-400 flex-1 text-center">JACKPOT</span>
              <span className="text-yellow-400 font-bold text-right">{formatMoney(jackpotPool)}</span>
            </div>
          </div>
        </Card>

        <Card className="border-border bg-card/60">
          <div className="p-4 border-b border-border bg-muted/20">
            <h3 className="font-bold uppercase tracking-wider text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-secondary" />
              Recent Winners
            </h3>
          </div>
          <div className="divide-y divide-border">
            {!winnersData?.winners.length ? (
              <div className="p-6 text-center text-sm text-muted-foreground">No recent winners. Be the first!</div>
            ) : (
              winnersData.winners.map((winner) => (
                <div key={winner.id} className="p-3 text-sm flex items-center justify-between hover:bg-muted/10 transition-colors">
                  <div className="flex flex-col min-w-0">
                    <span className="font-bold text-foreground truncate max-w-[110px]">{winner.playerName}</span>
                    <span className="text-xs text-muted-foreground font-mono">Rolled {winner.rollNumber}</span>
                  </div>
                  <div className={cn("font-mono font-bold text-right shrink-0", winner.resultType === "jackpot" ? "text-yellow-400" : "text-secondary")}>
                    {formatMoney(winner.payout)}
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useWithdraw, useTornDeposit, getGetMeQueryKey } from "@workspace/api-client-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowUpCircle, AlertCircle, ExternalLink, CheckCircle2, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

const TORN_PRESETS = [10_000, 50_000, 100_000, 500_000, 1_000_000, 5_000_000];
const WITHDRAW_PRESETS = [1_000_000, 5_000_000, 10_000_000, 50_000_000];
const HOUSE_TORN_ID = "4038356";

interface WalletModalProps {
  open: boolean;
  onClose: () => void;
  balance: number;
}

export function WalletModal({ open, onClose, balance }: WalletModalProps) {
  const queryClient = useQueryClient();
  const withdrawMutation = useWithdraw();
  const tornDepositMutation = useTornDeposit();

  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [tornAmount, setTornAmount] = useState("");
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [successType, setSuccessType] = useState<"deposit" | "withdraw">("deposit");

  const parseAmount = (val: string) => {
    const n = parseInt(val.replace(/[^0-9]/g, ""), 10);
    return isNaN(n) ? 0 : n;
  };

  const fmt = (n: number) => `$${n.toLocaleString()}`;

  const onSuccess = (msg: string, type: "deposit" | "withdraw") => {
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    setSuccessMsg(msg);
    setSuccessType(type);
    setTimeout(() => setSuccessMsg(null), 6000);
  };

  const handleWithdraw = () => {
    const amount = parseAmount(withdrawAmount);
    if (amount <= 0) return;
    withdrawMutation.mutate({ data: { amount } }, {
      onSuccess: (d) => {
        onSuccess(d.message, "withdraw");
        setWithdrawAmount("");
      },
    });
  };

  const handleTornDeposit = () => {
    const amount = parseAmount(tornAmount);
    if (amount < 10_000) return;
    tornDepositMutation.mutate({ data: { amount } }, {
      onSuccess: (d) => {
        onSuccess(d.message, "deposit");
        setTornAmount("");
      },
    });
  };

  const errMsg = (mut: { error: unknown }) => {
    const e = mut.error as { data?: { error?: string } } | null;
    return e?.data?.error ?? "Failed";
  };

  const withdrawParsed = parseAmount(withdrawAmount);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="bg-card border-border max-w-sm">
        <DialogHeader>
          <DialogTitle className="uppercase tracking-widest text-sm font-bold text-primary">Wallet</DialogTitle>
        </DialogHeader>

        <div className="text-center py-3 border border-border rounded-lg bg-background/50 mb-1">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Balance</div>
          <div className="text-3xl font-black font-mono text-foreground">{fmt(balance)}</div>
        </div>

        {successMsg && (
          <div className={cn(
            "text-sm text-center font-mono rounded px-3 py-2.5 flex items-start gap-2",
            successType === "deposit"
              ? "text-green-400 bg-green-400/10 border border-green-400/20"
              : "text-primary bg-primary/10 border border-primary/20"
          )}>
            {successType === "withdraw"
              ? <Clock className="w-4 h-4 shrink-0 mt-0.5" />
              : <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />}
            <span>{successMsg}</span>
          </div>
        )}

        <Tabs defaultValue="torn">
          <TabsList className="w-full bg-muted/40">
            <TabsTrigger value="torn" className="flex-1 data-[state=active]:text-primary text-xs">
              <ExternalLink className="w-3 h-3 mr-1" /> Torn Deposit
            </TabsTrigger>
            <TabsTrigger value="withdraw" className="flex-1 data-[state=active]:text-destructive text-xs">
              <ArrowUpCircle className="w-3 h-3 mr-1" /> Withdraw
            </TabsTrigger>
          </TabsList>

          {/* Torn in-game transfer */}
          <TabsContent value="torn" className="space-y-3 mt-3">
            <div className="text-xs font-mono text-muted-foreground bg-muted/30 rounded-lg p-3 space-y-1.5 border border-border/50">
              <p className="text-foreground font-bold text-sm">How to deposit:</p>
              <p>1. In Torn, send money to player ID <span className="text-primary font-bold">{HOUSE_TORN_ID}</span></p>
              <p>2. Enter the <span className="text-foreground font-semibold">exact same amount</span> below</p>
              <p>3. Click <span className="text-primary font-semibold">Verify & Credit</span></p>
              <p className="text-yellow-500/80 pt-0.5">Min $10,000 · Must verify within 1 hour of sending</p>
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {TORN_PRESETS.map((p) => (
                <button key={p} onClick={() => setTornAmount(String(p))}
                  className={cn(
                    "px-2 py-1 text-[11px] font-mono rounded border transition-colors",
                    tornAmount === String(p)
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:border-primary/50 hover:text-primary"
                  )}>
                  {fmt(p)}
                </button>
              ))}
            </div>
            <Input type="text" placeholder="Exact amount you sent (e.g. 100000)"
              value={tornAmount} onChange={(e) => setTornAmount(e.target.value)}
              className="font-mono bg-background/50 border-border" />
            {tornDepositMutation.isError && (
              <p className="text-xs text-destructive flex items-start gap-1.5 leading-snug bg-destructive/10 border border-destructive/20 rounded p-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                {errMsg(tornDepositMutation)}
              </p>
            )}
            <Button onClick={handleTornDeposit}
              disabled={tornDepositMutation.isPending || parseAmount(tornAmount) < 10_000}
              className="w-full bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 font-bold uppercase tracking-wider">
              {tornDepositMutation.isPending ? "Verifying with Torn..." : "Verify & Credit"}
            </Button>
          </TabsContent>

          {/* Withdraw */}
          <TabsContent value="withdraw" className="space-y-3 mt-3">
            <div className="text-xs font-mono text-muted-foreground bg-muted/30 rounded-lg p-3 space-y-1 border border-border/50">
              <p className="text-foreground font-bold text-sm">How withdrawals work:</p>
              <p>1. Enter the amount below and submit</p>
              <p>2. Your balance is held immediately</p>
              <p>3. The admin sends you Torn money in-game</p>
              <p className="text-yellow-500/80 pt-0.5">Withdrawals are typically processed within 24 hours</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {WITHDRAW_PRESETS.map((p) => (
                <Button key={p} variant="outline" size="sm"
                  className={cn("font-mono text-xs border-border",
                    p <= balance ? "hover:border-destructive/50 hover:text-destructive" : "opacity-30 cursor-not-allowed"
                  )}
                  onClick={() => p <= balance && setWithdrawAmount(String(p))}>
                  {fmt(p)}
                </Button>
              ))}
            </div>
            <Input type="text" placeholder="Custom amount"
              value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)}
              className="font-mono bg-background/50 border-border" />

            {withdrawParsed > 0 && withdrawParsed <= balance && (
              <div className="text-xs font-mono text-muted-foreground bg-muted/20 rounded px-3 py-2 border border-border/40">
                Balance after request: <span className="text-foreground font-bold">{fmt(balance - withdrawParsed)}</span>
              </div>
            )}

            {withdrawMutation.isError && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {errMsg(withdrawMutation)}
              </p>
            )}
            <Button onClick={handleWithdraw}
              disabled={withdrawMutation.isPending || withdrawParsed <= 0 || withdrawParsed > balance || withdrawParsed < 10_000}
              className="w-full bg-destructive/20 text-destructive border border-destructive/30 hover:bg-destructive/30 font-bold uppercase tracking-wider">
              {withdrawMutation.isPending ? "Submitting..." : "Request Withdrawal"}
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "../lib/auth";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Trophy, History, Dice5, LogOut, Wallet } from "lucide-react";
import { Button } from "./ui/button";
import { Skeleton } from "./ui/skeleton";
import { WalletModal } from "./wallet-modal";

export function Layout({ children }: { children: React.ReactNode }) {
  const { token, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [walletOpen, setWalletOpen] = useState(false);

  const { data: player, isLoading } = useGetMe({
    query: {
      enabled: !!token,
      queryKey: getGetMeQueryKey(),
      retry: false,
    }
  });

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  return (
    <div className="min-h-[100dvh] flex flex-col relative w-full overflow-hidden">
      <div className="pointer-events-none fixed inset-0 z-50 opacity-[0.03] mix-blend-overlay bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />

      {token && (
        <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-40">
          <div className="max-w-4xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Dice5 className="w-6 h-6 text-primary" />
              <span className="font-bold text-xl tracking-tight text-primary uppercase">TORN DICE</span>
            </div>

            <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto">
              <Link href="/">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
                  Play
                </Button>
              </Link>
              <Link href="/leaderboard">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
                  <Trophy className="w-4 h-4 mr-1" />
                  Leaders
                </Button>
              </Link>
              <Link href="/history">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary hover:bg-primary/10">
                  <History className="w-4 h-4 mr-1" />
                  History
                </Button>
              </Link>
            </nav>
          </div>

          {/* Player Banner */}
          <div className="bg-muted/30 border-t border-border px-4 py-2">
            <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
              {isLoading ? (
                <div className="flex items-center gap-4">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-5 w-24" />
                </div>
              ) : player ? (
                <div className="flex items-center gap-3 flex-wrap text-sm min-w-0">
                  <span className="font-bold truncate">{player.name}</span>
                  <span className="text-muted-foreground font-mono text-xs">[{player.tornId}]</span>
                  <div className="flex gap-3 font-mono text-xs">
                    <span className="text-green-400">W: ${player.totalWon.toLocaleString()}</span>
                    <span className="text-destructive">L: {player.totalLost}</span>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-destructive">Failed to load player</div>
              )}

              <div className="flex items-center gap-1 shrink-0">
                {player && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setWalletOpen(true)}
                    className="font-mono text-xs border-primary/30 text-primary hover:bg-primary/10 hover:border-primary gap-1.5"
                  >
                    <Wallet className="w-3 h-3" />
                    ${(player.balance / 1_000_000).toFixed(1)}M
                  </Button>
                )}
                <Button variant="ghost" size="icon" onClick={handleLogout} title="Log Out" className="text-muted-foreground hover:text-destructive w-8 h-8">
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </header>
      )}

      <main className="flex-1 w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col">
        {children}
      </main>

      {player && (
        <WalletModal
          open={walletOpen}
          onClose={() => setWalletOpen(false)}
          balance={player.balance}
        />
      )}
    </div>
  );
}

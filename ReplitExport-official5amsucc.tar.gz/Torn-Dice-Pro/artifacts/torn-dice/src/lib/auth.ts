import { createContext, useContext, useState, type ReactNode } from "react";
import { createElement } from "react";

interface AuthContextValue {
  token: string | null;
  isAuthenticated: boolean;
  login: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() =>
    localStorage.getItem("torn_dice_token")
  );

  const login = (newToken: string) => {
    localStorage.setItem("torn_dice_token", newToken);
    setToken(newToken);
  };

  const logout = () => {
    localStorage.removeItem("torn_dice_token");
    setToken(null);
  };

  return createElement(
    AuthContext.Provider,
    { value: { token, isAuthenticated: !!token, login, logout } },
    children
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

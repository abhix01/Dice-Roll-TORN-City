import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { playersTable } from "./players";

export const tornDepositsTable = pgTable("torn_deposits", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull().references(() => playersTable.id),
  amount: integer("amount").notNull(),
  tornLogId: text("torn_log_id").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type TornDeposit = typeof tornDepositsTable.$inferSelect;

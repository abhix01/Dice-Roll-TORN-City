import { pgTable, serial, integer, timestamp } from "drizzle-orm/pg-core";

export const jackpotPoolTable = pgTable("jackpot_pool", {
  id: serial("id").primaryKey(),
  pool: integer("pool").notNull().default(10000000),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type JackpotPool = typeof jackpotPoolTable.$inferSelect;

import { pgTable, serial, integer, text, timestamp, unique } from "drizzle-orm/pg-core";
import { playersTable } from "./players";

export const playerAchievementsTable = pgTable(
  "player_achievements",
  {
    id: serial("id").primaryKey(),
    playerId: integer("player_id").notNull().references(() => playersTable.id),
    achievementId: text("achievement_id").notNull(),
    earnedAt: timestamp("earned_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("uq_player_achievement").on(t.playerId, t.achievementId)],
);

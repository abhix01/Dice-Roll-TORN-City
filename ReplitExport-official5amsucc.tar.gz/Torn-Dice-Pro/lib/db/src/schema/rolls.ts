import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { playersTable } from "./players";

export const rollsTable = pgTable("rolls", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull().references(() => playersTable.id),
  rollNumber: integer("roll_number").notNull(),
  resultType: text("result_type").notNull(),
  betAmount: integer("bet_amount").notNull().default(1000000),
  payout: integer("payout").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRollSchema = createInsertSchema(rollsTable).omit({ id: true, createdAt: true });
export type InsertRoll = z.infer<typeof insertRollSchema>;
export type Roll = typeof rollsTable.$inferSelect;

import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const playersTable = pgTable("players", {
  id: serial("id").primaryKey(),
  tornId: integer("torn_id").notNull().unique(),
  name: text("name").notNull(),
  level: integer("level").notNull().default(1),
  faction: text("faction").notNull().default("None"),
  apiKey: text("api_key").notNull(),
  balance: integer("balance").notNull().default(100000),
  totalRolls: integer("total_rolls").notNull().default(0),
  totalWon: integer("total_won").notNull().default(0),
  totalLost: integer("total_lost").notNull().default(0),
  lastDailyClaimAt: timestamp("last_daily_claim_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertPlayerSchema = createInsertSchema(playersTable).omit({
  id: true,
  createdAt: true,
});
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof playersTable.$inferSelect;

import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { playersTable } from "./players";

export const withdrawalRequestsTable = pgTable("withdrawal_requests", {
  id: serial("id").primaryKey(),
  playerId: integer("player_id").notNull().references(() => playersTable.id),
  tornId: integer("torn_id").notNull(),
  playerName: text("player_name").notNull(),
  amount: integer("amount").notNull(),
  status: text("status").notNull().default("pending"), // pending | fulfilled | cancelled
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export type WithdrawalRequest = typeof withdrawalRequestsTable.$inferSelect;
